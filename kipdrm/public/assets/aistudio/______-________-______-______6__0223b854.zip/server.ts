import express from 'express';
import { createServer as createViteServer } from 'vite';
import { db, pool } from './src/db/index.ts';
import { users, registers, documentLocks } from './src/db/schema.ts';
import { eq, and, sql } from 'drizzle-orm';
import crypto from 'node:crypto';
import { INITIAL_USERS, createAcceptanceRegister } from './src/utils/acceptanceData.ts';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Secure Password Hashing helpers using crypto.scrypt
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  // Fallback for legacy unhashed passwords during migration
  if (!storedHash.includes(':')) {
    return password === storedHash;
  }
  const [salt, key] = storedHash.split(':');
  if (!salt || !key) return false;
  const keyBuffer = Buffer.from(key, 'hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(keyBuffer, derivedKey);
}

// Initial database seed helper
async function seedDatabaseIfEmpty() {
  try {
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length === 0) {
      console.log('Seeding initial users into PostgreSQL with hashed passwords...');
      for (const u of INITIAL_USERS) {
        const hashed = hashPassword(u.password || 'kior2026');
        await db.insert(users).values({
          uid: u.id,
          name: u.name,
          login: u.login,
          password: hashed,
          position: u.position,
          department: u.department,
          role: u.role,
          email: u.email,
        }).onConflictDoNothing();
      }
    }

    const existingRegisters = await db.select().from(registers).limit(1);
    if (existingRegisters.length === 0) {
      console.log('Seeding initial acceptance register into PostgreSQL...');
      const initialDoc = createAcceptanceRegister();
      await db.insert(registers).values({
        id: initialDoc.id,
        department: initialDoc.header.department,
        quarter: initialDoc.header.quarter,
        year: initialDoc.header.year,
        status: initialDoc.status,
        documentData: initialDoc,
      }).onConflictDoNothing();
    }
  } catch (err) {
    console.error('Database seeding error:', err);
  }
}

// ==========================================
// API ROUTES
// ==========================================

// Health check
app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (err) {
    res.status(500).json({ status: 'error', message: String(err) });
  }
});

// USERS API
// Returns user list WITHOUT leaking raw password hashes to the client
app.get('/api/users', async (_req, res) => {
  try {
    const rows = await db.select().from(users);
    const userProfiles = rows.map((r) => ({
      id: r.uid,
      name: r.name,
      login: r.login,
      hasPassword: Boolean(r.password),
      position: r.position,
      department: r.department,
      role: r.role,
      email: r.email || '',
    }));
    res.json(userProfiles);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Failed to load users' });
  }
});

app.post('/api/users', async (req, res) => {
  try {
    const { name, login, password, position, department, role, email } = req.body;
    const uid = `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const hashedPassword = hashPassword(password || 'kior2026');

    await db.insert(users).values({
      uid,
      name: name || '',
      login: login || '',
      password: hashedPassword,
      position: position || '',
      department: department || '',
      role: role || 'department',
      email: email || '',
    });

    res.json({ id: uid, name, login, hasPassword: true, position, department, role, email });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

app.put('/api/users/:uid', async (req, res) => {
  try {
    const { uid } = req.params;
    const patch = req.body;
    const updateValues: Record<string, any> = {};

    if (patch.name !== undefined) updateValues.name = patch.name;
    if (patch.login !== undefined) updateValues.login = patch.login;
    if (patch.password !== undefined && patch.password.trim() !== '') {
      updateValues.password = hashPassword(patch.password.trim());
    }
    if (patch.position !== undefined) updateValues.position = patch.position;
    if (patch.department !== undefined) updateValues.department = patch.department;
    if (patch.role !== undefined) updateValues.role = patch.role;
    if (patch.email !== undefined) updateValues.email = patch.email;

    await db.update(users).set(updateValues).where(eq(users.uid, uid));
    res.json({ success: true });
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

app.delete('/api/users/:uid', async (req, res) => {
  try {
    const { uid } = req.params;
    await db.delete(users).where(eq(users.uid, uid));
    res.json({ success: true });
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// AUTH API
app.post('/api/auth/login', async (req, res) => {
  try {
    const { loginOrEmail, password } = req.body;
    if (!loginOrEmail || !password) {
      return res.status(400).json({ error: 'Missing login or password' });
    }
    const clean = String(loginOrEmail).trim().toLowerCase();
    const rows = await db.select().from(users);
    const found = rows.find(
      (u) =>
        u.login.toLowerCase() === clean ||
        (u.email && u.email.toLowerCase() === clean) ||
        u.role.toLowerCase() === clean
    );

    if (!found || !verifyPassword(password, found.password)) {
      return res.status(401).json({ error: 'Неверный логин или пароль' });
    }

    const userProfile = {
      id: found.uid,
      name: found.name,
      login: found.login,
      position: found.position,
      department: found.department,
      role: found.role,
      email: found.email || '',
    };
    res.json({ user: userProfile });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==========================================
// DOCUMENT LOCKS API (CONCURRENCY CONTROL)
// ==========================================
const LOCK_TIMEOUT_MS = 60 * 1000; // 60 seconds heartbeat timeout

// Acquire lock or heartbeat
app.post('/api/registers/:id/lock', async (req, res) => {
  try {
    const { id } = req.params;
    const { userId, userName, userDepartment } = req.body;

    if (!userId || !userName) {
      return res.status(400).json({ error: 'Missing user identification' });
    }

    const now = new Date();
    const expiryThreshold = new Date(now.getTime() - LOCK_TIMEOUT_MS);

    // Clean up stale locks for this document
    await db
      .delete(documentLocks)
      .where(and(eq(documentLocks.documentId, id), sql`${documentLocks.heartbeatAt} < ${expiryThreshold}`));

    // Check existing lock
    const existing = await db.select().from(documentLocks).where(eq(documentLocks.documentId, id));

    if (existing.length > 0 && existing[0].lockedByUserId !== userId) {
      // Locked by another user!
      return res.status(423).json({
        locked: true,
        canEdit: false,
        lockedByUserId: existing[0].lockedByUserId,
        lockedByUserName: existing[0].lockedByUserName,
        lockedByUserDepartment: existing[0].lockedByUserDepartment,
        lockedAt: existing[0].lockedAt,
        message: `Документ редактируется пользователем: ${existing[0].lockedByUserName} (${existing[0].lockedByUserDepartment}). Изменения заблокированы во избежание перезаписи.`,
      });
    }

    // Upsert lock
    await db
      .insert(documentLocks)
      .values({
        documentId: id,
        lockedByUserId: userId,
        lockedByUserName: userName,
        lockedByUserDepartment: userDepartment || '',
        lockedAt: now,
        heartbeatAt: now,
      })
      .onConflictDoUpdate({
        target: documentLocks.documentId,
        set: {
          lockedByUserId: userId,
          lockedByUserName: userName,
          lockedByUserDepartment: userDepartment || '',
          heartbeatAt: now,
        },
      });

    res.json({ locked: true, canEdit: true });
  } catch (err) {
    console.error('Error locking document:', err);
    res.status(500).json({ error: 'Failed to process document lock' });
  }
});

// Release lock
app.delete('/api/registers/:id/lock', async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body || {};

    if (userId) {
      await db
        .delete(documentLocks)
        .where(and(eq(documentLocks.documentId, id), eq(documentLocks.lockedByUserId, userId)));
    } else {
      await db.delete(documentLocks).where(eq(documentLocks.documentId, id));
    }

    res.json({ success: true });
  } catch (err) {
    console.error('Error releasing lock:', err);
    res.status(500).json({ error: 'Failed to release lock' });
  }
});

// Get current lock status
app.get('/api/registers/:id/lock', async (req, res) => {
  try {
    const { id } = req.params;
    const now = new Date();
    const expiryThreshold = new Date(now.getTime() - LOCK_TIMEOUT_MS);

    const existing = await db
      .select()
      .from(documentLocks)
      .where(and(eq(documentLocks.documentId, id), sql`${documentLocks.heartbeatAt} >= ${expiryThreshold}`));

    if (existing.length === 0) {
      return res.json({ locked: false });
    }

    res.json({
      locked: true,
      lockedByUserId: existing[0].lockedByUserId,
      lockedByUserName: existing[0].lockedByUserName,
      lockedByUserDepartment: existing[0].lockedByUserDepartment,
      lockedAt: existing[0].lockedAt,
    });
  } catch (err) {
    console.error('Error querying lock:', err);
    res.status(500).json({ error: 'Failed to query lock status' });
  }
});

// ==========================================
// REGISTERS API
// ==========================================
app.get('/api/registers', async (_req, res) => {
  try {
    const rows = await db.select().from(registers);
    const docs = rows.map((r) => r.documentData);
    res.json(docs);
  } catch (err) {
    console.error('Error fetching registers:', err);
    res.status(500).json({ error: 'Failed to load registers' });
  }
});

app.get('/api/registers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const rows = await db.select().from(registers).where(eq(registers.id, id));
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Register not found' });
    }
    res.json(rows[0].documentData);
  } catch (err) {
    console.error('Error fetching register:', err);
    res.status(500).json({ error: 'Failed to load register' });
  }
});

app.post('/api/registers', async (req, res) => {
  try {
    const doc = req.body;
    if (!doc || !doc.id) {
      return res.status(400).json({ error: 'Invalid document' });
    }

    const { userId } = req.query;
    if (userId) {
      const now = new Date();
      const expiryThreshold = new Date(now.getTime() - LOCK_TIMEOUT_MS);
      const existingLock = await db
        .select()
        .from(documentLocks)
        .where(and(eq(documentLocks.documentId, doc.id), sql`${documentLocks.heartbeatAt} >= ${expiryThreshold}`));

      if (existingLock.length > 0 && existingLock[0].lockedByUserId !== userId) {
        return res.status(423).json({
          error: `Документ заблокирован пользователем ${existingLock[0].lockedByUserName}`,
        });
      }
    }

    const updatedAt = new Date();
    await db
      .insert(registers)
      .values({
        id: doc.id,
        department: doc.header?.department || '',
        quarter: doc.header?.quarter || 'IV',
        year: doc.header?.year || 2026,
        status: doc.status || 'draft',
        documentData: { ...doc, updatedAt: updatedAt.toISOString() },
        updatedAt,
      })
      .onConflictDoUpdate({
        target: registers.id,
        set: {
          department: doc.header?.department || '',
          quarter: doc.header?.quarter || 'IV',
          year: doc.header?.year || 2026,
          status: doc.status || 'draft',
          documentData: { ...doc, updatedAt: updatedAt.toISOString() },
          updatedAt,
        },
      });

    res.json({ success: true, doc: { ...doc, updatedAt: updatedAt.toISOString() } });
  } catch (err) {
    console.error('Error saving register:', err);
    res.status(500).json({ error: 'Failed to save register' });
  }
});

app.put('/api/registers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const doc = req.body;

    const { userId } = req.query;
    if (userId) {
      const now = new Date();
      const expiryThreshold = new Date(now.getTime() - LOCK_TIMEOUT_MS);
      const existingLock = await db
        .select()
        .from(documentLocks)
        .where(and(eq(documentLocks.documentId, id), sql`${documentLocks.heartbeatAt} >= ${expiryThreshold}`));

      if (existingLock.length > 0 && existingLock[0].lockedByUserId !== userId) {
        return res.status(423).json({
          error: `Документ заблокирован пользователем ${existingLock[0].lockedByUserName}`,
        });
      }
    }

    const updatedAt = new Date();
    const updatedDoc = { ...doc, id, updatedAt: updatedAt.toISOString() };

    await db
      .insert(registers)
      .values({
        id,
        department: doc.header?.department || '',
        quarter: doc.header?.quarter || 'IV',
        year: doc.header?.year || 2026,
        status: doc.status || 'draft',
        documentData: updatedDoc,
        updatedAt,
      })
      .onConflictDoUpdate({
        target: registers.id,
        set: {
          department: doc.header?.department || '',
          quarter: doc.header?.quarter || 'IV',
          year: doc.header?.year || 2026,
          status: doc.status || 'draft',
          documentData: updatedDoc,
          updatedAt,
        },
      });

    res.json({ success: true, doc: updatedDoc });
  } catch (err) {
    console.error('Error updating register:', err);
    res.status(500).json({ error: 'Failed to update register' });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  await seedDatabaseIfEmpty();

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

startServer();
