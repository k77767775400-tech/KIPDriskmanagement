/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { calculateRiskScore, getRatingDetails, calculateEffectiveness } from './calculations';
import { validateRegister } from './validation';
import { createAcceptanceRegister } from './acceptanceData';
import { generateRiskRegisterWorkbook } from './excelExport';

export interface TestResult {
  id: string;
  name: string;
  category: string;
  passed: boolean;
  message: string;
  details?: string;
}

export async function runAllAcceptanceTests(): Promise<TestResult[]> {
  const results: TestResult[] = [];

  const add = (id: string, name: string, category: string, passed: boolean, message: string, details?: string) => {
    results.push({ id, name, category, passed, message, details });
  };

  // ----------------------------------------------------
  // TEST GROUP 1: Calculation, score, rating and zone boundaries
  // ----------------------------------------------------
  try {
    // Formula check: (p + t) * i
    const baseScore = calculateRiskScore(3, 2, 4); // (3+2)*4 = 20
    add(
      't1_1',
      'Базовая формула балла значимости',
      'Расчеты',
      baseScore === 20,
      baseScore === 20 ? 'Пройден: (3+2)*4 = 20' : `Ошибка: получено ${baseScore}, ожидалось 20`
    );

    // Boundary 7 vs 8 (Низкая vs Средняя)
    const score7 = 7;
    const r7 = getRatingDetails(score7);
    const score8 = 8;
    const r8 = getRatingDetails(score8);
    const passBound8 = r7.ratingCode === '0,6' && r7.zone === 'Зелёная' && r8.ratingCode === '0,8' && r8.zone === 'Жёлтая';
    add(
      't1_2',
      'Граница рейтинга 7/8 (0,6 низкая / 0,8 средняя)',
      'Расчеты',
      passBound8,
      passBound8 ? 'Пройден: 7 -> 0,6 Зеленая, 8 -> 0,8 Желтая' : `Ошибка: 7=${r7.ratingCode}, 8=${r8.ratingCode}`
    );

    // Boundary 14 vs 15 (Средняя vs Высокая)
    const score14 = 14;
    const r14 = getRatingDetails(score14);
    const score15 = 15;
    const r15 = getRatingDetails(score15);
    const passBound15 = r14.ratingCode === '0,8' && r14.zone === 'Жёлтая' && r15.ratingCode === '0,9' && r15.zone === 'Оранжевая';
    add(
      't1_3',
      'Граница рейтинга 14/15 (0,8 средняя / 0,9 высокая)',
      'Расчеты',
      passBound15,
      passBound15 ? 'Пройден: 14 -> 0,8 Желтая, 15 -> 0,9 Оранжевая' : `Ошибка: 14=${r14.ratingCode}, 15=${r15.ratingCode}`
    );

    // Boundary 27 vs 28 (Высокая vs Крайне высокая)
    const score27 = 27;
    const r27 = getRatingDetails(score27);
    const score28 = 28;
    const r28 = getRatingDetails(score28);
    const passBound28 = r27.ratingCode === '0,9' && r27.zone === 'Оранжевая' && r28.ratingCode === '1,0' && r28.zone === 'Красная';
    add(
      't1_4',
      'Граница рейтинга 27/28 (0,9 высокая / 1,0 крайне высокая)',
      'Расчеты',
      passBound28,
      passBound28 ? 'Пройден: 27 -> 0,9 Оранжевая, 28 -> 1,0 Красная' : `Ошибка: 27=${r27.ratingCode}, 28=${r28.ratingCode}`
    );

    // Boundaries 0 and 1
    const r0 = getRatingDetails(0);
    const r1 = getRatingDetails(1);
    const passBound01 = r0.ratingCode === '0,5' && r1.ratingCode === '0,6';
    add(
      't1_5',
      'Граничные значения 0 и 1',
      'Расчеты',
      passBound01,
      passBound01 ? 'Пройден: 0 -> 0,5, 1 -> 0,6' : `Ошибка: 0=${r0.ratingCode}, 1=${r1.ratingCode}`
    );
  } catch (e: any) {
    add('t1_err', 'Тест формул', 'Расчеты', false, e?.message || 'Exception in calculations test');
  }

  // ----------------------------------------------------
  // TEST GROUP 2: Effectiveness formulas
  // ----------------------------------------------------
  try {
    const effLower = calculateEffectiveness(20, 4);
    const passEffLower = effLower.isEffective && effLower.text === 'Эффективно: 20 → 4';
    add(
      't2_1',
      'Расчет эффективности (остаточный ниже присущего)',
      'Эффективность',
      passEffLower,
      passEffLower ? 'Пройден: Эффективно: 20 → 4' : `Ошибка: ${effLower.text}`
    );

    const effEqual = calculateEffectiveness(12, 12);
    const passEffEqual = !effLower.isError && effEqual.text === 'Риск не снижен';
    add(
      't2_2',
      'Расчет эффективности (остаточный равен присущему)',
      'Эффективность',
      passEffEqual,
      passEffEqual ? 'Пройден: Риск не снижен' : `Ошибка: ${effEqual.text}`
    );

    const effHigher = calculateEffectiveness(10, 16);
    const passEffHigher = effHigher.isError && effHigher.text === 'Ошибка: остаточный выше присущего';
    add(
      't2_3',
      'Расчет эффективности (остаточный выше присущего)',
      'Эффективность',
      passEffHigher,
      passEffHigher ? 'Пройден: Зафиксирована ошибка' : `Ошибка: ${effHigher.text}`
    );
  } catch (e: any) {
    add('t2_err', 'Тест эффективности', 'Эффективность', false, e?.message || 'Exception');
  }

  // ----------------------------------------------------
  // TEST GROUP 3: Validation rules & blocking constraints
  // ----------------------------------------------------
  try {
    // 3.1: Seed register should be 100% valid
    const seed = createAcceptanceRegister();
    const seedVal = validateRegister(seed);
    add(
      't3_1',
      'Валидация эталонного регистра (Отдел AI, III кв. 2026)',
      'Валидация',
      seedVal.isValid,
      seedVal.isValid
        ? 'Пройден: эталонный регистр полностью валиден (0 блокирующих ошибок)'
        : `Ошибка: ${seedVal.blockingErrors.map((b) => b.message).join('; ')}`
    );

    // 3.2: Residual > Inherent must trigger BLOCKING error
    const brokenResidual = createAcceptanceRegister();
    brokenResidual.risks[0].residualImpact = 5;
    brokenResidual.risks[0].residualProbability = 5;
    brokenResidual.risks[0].residualTimeImpact = 3; // (5+3)*5 = 40 > 20
    const valRes = validateRegister(brokenResidual);
    const blockedByResidual = valRes.blockingErrors.some((b) => b.section === 'Регистр Ч.3');
    add(
      't3_2',
      'Блокировка отправки: остаточный риск выше присущего',
      'Валидация',
      blockedByResidual,
      blockedByResidual
        ? 'Пройден: отправка заблокирована ошибкой Ч.3'
        : 'Ошибка: превышение остаточного риска не заблокировало регистр'
    );

    // 3.3: Risk with rating 0.9/1.0 without KPR must trigger BLOCKING error
    const noKprDoc = createAcceptanceRegister();
    noKprDoc.kprList = []; // Remove KPR row for 5-О-01 (score 20 >= 15)
    const valKpr = validateRegister(noKprDoc);
    const blockedByKpr = valKpr.blockingErrors.some((b) => b.section === 'Панель КПР');
    add(
      't3_3',
      'Блокировка отправки: высокий риск (0,9 / 1,0) без строки в Панели КПР',
      'Валидация',
      blockedByKpr,
      blockedByKpr
        ? 'Пройден: отсутствие КПР для риска 5-О-01 заблокировало регистр'
        : 'Ошибка: регистр с рейтингом 0.9 без КПР ошибочно прошел валидацию'
    );

    // 3.4: Wrong class letter (Latin instead of Cyrillic or wrong class block)
    const wrongClassDoc = createAcceptanceRegister();
    wrongClassDoc.risks[0].riskNumber = '1-С-05'; // Sticking a 1-С number inside class 5-О
    const valClass = validateRegister(wrongClassDoc);
    const blockedByClass = valClass.blockingErrors.some((b) => b.message.includes('не соответствует формату класса'));
    add(
      't3_4',
      'Блокировка: несоответствие буквы/префикса класса риска',
      'Валидация',
      blockedByClass,
      blockedByClass
        ? 'Пройден: номер 1-С-05 в блоке 5-О заблокирован'
        : 'Ошибка: несовпадение класса не было заблокировано'
    );
  } catch (e: any) {
    add('t3_err', 'Тест валидации', 'Валидация', false, e?.message || 'Exception');
  }

  // ----------------------------------------------------
  // TEST GROUP 4: Excel round-trip & row alignment
  // ----------------------------------------------------
  try {
    const testDoc = createAcceptanceRegister();
    // Add multiple risks to class 5-О to test 9th risk insertion
    for (let i = 3; i <= 9; i++) {
      testDoc.risks.push({
        id: `r_5_o_0${i}`,
        riskNumber: `5-О-0${i}`,
        classId: '5-О',
        name: `Дополнительный операционный риск №${i}`,
        factors: [`Фактор риска ${i}`],
        consequences: [`Последствие риска ${i}`],
        ownerUnit: 'Отдел данных, цифровых решений и AI',
        probability: 2,
        timeImpact: 1,
        impact: 2,
        measures: [
          {
            id: `m_extra_${i}`,
            name: `Мероприятие для риска ${i}`,
            goal: 'Б',
            estimatedCost: 0,
            costBenefitAnalysis: 'Штатные меры',
            deadline: '30.09.2026',
            completionForm: 'Отчет',
            responsibleUnit: 'Отдел данных, цифровых решений и AI',
            status: 'В процессе исполнения',
          },
        ],
        residualProbability: 1,
        residualTimeImpact: 1,
        residualImpact: 2,
      });
    }

    const workbook = await generateRiskRegisterWorkbook(testDoc);
    const sheetInst = workbook.getWorksheet('Инструкция');
    const sheetP1 = workbook.getWorksheet('Регистр Ч.1');
    const sheetP2 = workbook.getWorksheet('Регистр Ч.2');
    const sheetP3 = workbook.getWorksheet('Регистр Ч.3');
    const sheetKpr = workbook.getWorksheet('Панель КПР');
    const sheetReal = workbook.getWorksheet('Реализованные риски');
    const sheetScales = workbook.getWorksheet('Шкалы оценки');

    const sheetsExist =
      !!sheetInst && !!sheetP1 && !!sheetP2 && !!sheetP3 && !!sheetKpr && !!sheetReal && !!sheetScales;

    // Check cells C4, C5, C6 in sheet 'Инструкция'
    const c4Val = sheetInst?.getCell('C4').value;
    const c5Val = sheetInst?.getCell('C5').value;
    const c6Val = sheetInst?.getCell('C6').value;
    const instCorrect =
      c4Val === testDoc.header.department &&
      c5Val === testDoc.header.periodString &&
      typeof c6Val === 'string' &&
      c6Val.includes(testDoc.header.coordinatorName);

    // Check that row count in Part 1, Part 2, and Part 3 are identical
    const p1Rows = sheetP1?.rowCount || 0;
    const p2Rows = sheetP2?.rowCount || 0;
    const p3Rows = sheetP3?.rowCount || 0;
    const rowsAligned = p1Rows > 0 && p1Rows === p2Rows && p2Rows === p3Rows;

    add(
      't4_1',
      'Генерация всех 7 листов рабочей книги Excel',
      'Excel Экспорт',
      sheetsExist,
      sheetsExist ? 'Пройден: Все 7 официальных листов созданы' : 'Ошибка: Не все листы созданы'
    );

    add(
      't4_2',
      'Заполнение ячеек заголовка C4, C5, C6 на листе «Инструкция»',
      'Excel Экспорт',
      instCorrect,
      instCorrect
        ? `Пройден: C4=${c4Val}, C5=${c5Val}`
        : `Ошибка: C4=${c4Val}, C5=${c5Val}, C6=${c6Val}`
    );

    add(
      't4_3',
      'Строгое выравнивание строк Ч.1, Ч.2, Ч.3 при 9+ рисках в классе',
      'Excel Экспорт',
      rowsAligned,
      rowsAligned
        ? `Пройден: Ч.1 (${p1Rows} строк) == Ч.2 (${p2Rows} строк) == Ч.3 (${p3Rows} строк)`
        : `Ошибка: Ч.1=${p1Rows}, Ч.2=${p2Rows}, Ч.3=${p3Rows}`
    );
  } catch (e: any) {
    add('t4_err', 'Тест генерации Excel', 'Excel Экспорт', false, e?.message || 'Exception in Excel test');
  }

  return results;
}
