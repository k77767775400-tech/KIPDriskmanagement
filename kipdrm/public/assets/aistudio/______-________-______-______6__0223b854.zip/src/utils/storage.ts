/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RiskRegisterDocument, NomenclatureItem, UserProfile } from '../types/risk';
import { createAcceptanceRegister, DEFAULT_NOMENCLATURE, INITIAL_USERS } from './acceptanceData';
import { getQuarterPeriodString } from './calculations';

const STORAGE_KEY_REGISTERS = 'kior_risk_registers_v1';
const STORAGE_KEY_NOMENCLATURE = 'kior_nomenclature_v1';
const STORAGE_KEY_USERS = 'kior_users_accounts_v1';
const STORAGE_KEY_AUTH_SESSION = 'kior_auth_session_v1';

// Synchronous cached state for instant rendering, synced seamlessly with backend PostgreSQL
let cachedRegisters: RiskRegisterDocument[] = [];
let cachedUsers: UserProfile[] = [];
let isRegistersInitialized = false;
let isUsersInitialized = false;

// Background API sync listeners
export async function syncFromBackend(): Promise<void> {
  try {
    const [regRes, userRes] = await Promise.all([
      fetch('/api/registers'),
      fetch('/api/users'),
    ]);
    if (regRes.ok) {
      const regData = await regRes.json();
      if (Array.isArray(regData) && regData.length > 0) {
        cachedRegisters = regData;
        localStorage.setItem(STORAGE_KEY_REGISTERS, JSON.stringify(regData));
        window.dispatchEvent(new CustomEvent('kior_registers_synced'));
      }
    }
    if (userRes.ok) {
      const userData = await userRes.json();
      if (Array.isArray(userData) && userData.length > 0) {
        cachedUsers = userData;
        localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(userData));
        window.dispatchEvent(new CustomEvent('kior_users_synced'));
      }
    }
  } catch (err) {
    console.warn('Backend sync deferred or using offline fallback:', err);
  }
}

// Auto-trigger initial sync in browser environment
if (typeof window !== 'undefined') {
  syncFromBackend();
}

// ==========================================
// REGISTERS
// ==========================================

export function getStoredRegisters(): RiskRegisterDocument[] {
  if (isRegistersInitialized && cachedRegisters.length > 0) {
    return cachedRegisters;
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY_REGISTERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        cachedRegisters = parsed;
        isRegistersInitialized = true;
        return cachedRegisters;
      }
    }
  } catch (e) {
    console.error('Failed to parse registers from localStorage:', e);
  }

  const initial = [createAcceptanceRegister()];
  cachedRegisters = initial;
  isRegistersInitialized = true;
  saveRegisters(initial);
  return initial;
}

export function saveRegisters(registersList: RiskRegisterDocument[]): void {
  cachedRegisters = registersList;
  try {
    localStorage.setItem(STORAGE_KEY_REGISTERS, JSON.stringify(registersList));
  } catch (e) {
    console.error('Failed to save registers to storage:', e);
  }

  // Also sync asynchronously to backend PostgreSQL
  for (const doc of registersList) {
    fetch('/api/registers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc),
    }).catch((err) => console.warn('Background register POST sync note:', err));
  }
}

export function saveRegister(doc: RiskRegisterDocument, _authorName = 'Пользователь'): RiskRegisterDocument {
  const list = getStoredRegisters();
  const updatedDoc: RiskRegisterDocument = {
    ...doc,
    updatedAt: new Date().toISOString(),
  };

  const existingIdx = list.findIndex((item) => item.id === doc.id);
  if (existingIdx >= 0) {
    list[existingIdx] = updatedDoc;
  } else {
    list.push(updatedDoc);
  }
  saveRegisters(list);

  // Sync to PostgreSQL
  fetch(`/api/registers/${encodeURIComponent(doc.id)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedDoc),
  }).catch((err) => console.warn('Background register PUT sync note:', err));

  return updatedDoc;
}

export function getRegisterById(id: string): RiskRegisterDocument | undefined {
  const list = getStoredRegisters();
  return list.find((item) => item.id === id);
}

export function getRegisterForDepartmentAndPeriod(
  dept: string,
  quarter: 'I' | 'II' | 'III' | 'IV',
  year: number
): RiskRegisterDocument | undefined {
  const list = getStoredRegisters();
  return list.find(
    (item) => item.header.department === dept && item.header.quarter === quarter && item.header.year === year
  );
}

export function createNewRegisterForDepartment(
  dept: string,
  quarter: 'I' | 'II' | 'III' | 'IV',
  year: number,
  coordinatorName: string,
  coordinatorPosition: string
): RiskRegisterDocument {
  const now = new Date().toISOString();
  const periodString = getQuarterPeriodString(quarter, year);
  const id = `reg_${encodeURIComponent(dept)}_${quarter}_${year}_${Date.now()}`;

  const newDoc: RiskRegisterDocument = {
    id,
    header: {
      department: dept,
      quarter,
      year,
      periodString,
      coordinatorName,
      coordinatorPosition,
      curatingDeputyName: 'Сапарбаев Е. Б.',
    },
    risks: [],
    kprList: [],
    realizedReport: {
      '1-С': { classId: '1-С', hasNoEvents: true, events: [] },
      '2-Ф': { classId: '2-Ф', hasNoEvents: true, events: [] },
      '3-П': { classId: '3-П', hasNoEvents: true, events: [] },
      '4-К': { classId: '4-К', hasNoEvents: true, events: [] },
      '5-О': { classId: '5-О', hasNoEvents: true, events: [] },
    },
    status: 'draft',
    version: 1,
    history: [
      {
        id: `aud_${Date.now()}`,
        timestamp: now,
        author: coordinatorName || 'Координатор',
        role: 'Координатор рисков',
        action: `Создание проекта регистра за ${quarter} квартал ${year} г.`,
      },
    ],
    createdAt: now,
    updatedAt: now,
  };

  saveRegister(newDoc);
  return newDoc;
}

export function copyFromPreviousQuarter(
  sourceDoc: RiskRegisterDocument,
  targetQuarter: 'I' | 'II' | 'III' | 'IV',
  targetYear: number,
  authorName: string
): RiskRegisterDocument {
  const now = new Date().toISOString();
  const newPeriodString = getQuarterPeriodString(targetQuarter, targetYear);
  const newId = `reg_${encodeURIComponent(sourceDoc.header.department)}_${targetQuarter}_${targetYear}_${Date.now()}`;

  const clonedRisks = sourceDoc.risks.map((risk) => ({
    ...risk,
    id: `r_copied_${risk.riskNumber}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    measures: (risk.measures || []).map((m) => ({
      ...m,
      id: `m_copied_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      status: m.status === 'Исполнено' ? ('Исполнено' as const) : ('В процессе исполнения' as const),
    })),
  }));

  const clonedKpr = (sourceDoc.kprList || []).map((k) => ({
    ...k,
    id: `kpr_copied_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
  }));

  const copiedDoc: RiskRegisterDocument = {
    id: newId,
    header: {
      ...sourceDoc.header,
      quarter: targetQuarter,
      year: targetYear,
      periodString: newPeriodString,
    },
    risks: clonedRisks,
    kprList: clonedKpr,
    realizedReport: {
      '1-С': { classId: '1-С', hasNoEvents: true, events: [] },
      '2-Ф': { classId: '2-Ф', hasNoEvents: true, events: [] },
      '3-П': { classId: '3-П', hasNoEvents: true, events: [] },
      '4-К': { classId: '4-К', hasNoEvents: true, events: [] },
      '5-О': { classId: '5-О', hasNoEvents: true, events: [] },
    },
    status: 'draft',
    version: 1,
    history: [
      {
        id: `aud_${Date.now()}`,
        timestamp: now,
        author: authorName,
        role: 'Координатор рисков',
        action: `Создано копированием из ${sourceDoc.header.quarter} квартала ${sourceDoc.header.year} г. (${clonedRisks.length} рисков перенесено)`,
      },
    ],
    createdAt: now,
    updatedAt: now,
  };

  saveRegister(copiedDoc);
  return copiedDoc;
}

// ==========================================
// NOMENCLATURE
// ==========================================
export function getStoredNomenclature(): NomenclatureItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_NOMENCLATURE);
    if (!raw) {
      saveNomenclature(DEFAULT_NOMENCLATURE);
      return DEFAULT_NOMENCLATURE;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_NOMENCLATURE;
  } catch (e) {
    return DEFAULT_NOMENCLATURE;
  }
}

export function saveNomenclature(items: NomenclatureItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_NOMENCLATURE, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save nomenclature:', e);
  }
}

export function addNomenclatureItem(item: NomenclatureItem): NomenclatureItem[] {
  const current = getStoredNomenclature();
  const exists = current.find((i) => i.riskNumber === item.riskNumber);
  let updated: NomenclatureItem[];
  if (exists) {
    updated = current.map((i) => (i.riskNumber === item.riskNumber ? item : i));
  } else {
    updated = [...current, item];
  }
  saveNomenclature(updated);
  return updated;
}

export function getNextFreeRiskNumber(classId: string, currentRisksInDoc: string[] = []): string {
  const nom = getStoredNomenclature();
  const allKnown = new Set<string>();
  nom.forEach((n) => allKnown.add(n.riskNumber));
  currentRisksInDoc.forEach((r) => allKnown.add(r));

  let maxSeq = 0;
  allKnown.forEach((rNum) => {
    if (rNum.startsWith(classId)) {
      const match = rNum.match(/-(\d+)$/);
      if (match) {
        const seq = parseInt(match[1], 10);
        if (!isNaN(seq) && seq > maxSeq) {
          maxSeq = seq;
        }
      }
    }
  });

  const nextSeq = (maxSeq + 1).toString().padStart(2, '0');
  return `${classId}-${nextSeq}`;
}

// ==========================================
// USER ACCOUNTS & AUTHENTICATION
// ==========================================

export function getStoredUsers(): UserProfile[] {
  if (isUsersInitialized && cachedUsers.length > 0) {
    return cachedUsers;
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY_USERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        cachedUsers = parsed;
        isUsersInitialized = true;
        return cachedUsers;
      }
    }
  } catch (e) {
    console.error('Failed to parse users:', e);
  }

  cachedUsers = INITIAL_USERS;
  isUsersInitialized = true;
  saveStoredUsers(INITIAL_USERS);
  return INITIAL_USERS;
}

export function saveStoredUsers(usersList: UserProfile[]): void {
  cachedUsers = usersList;
  try {
    localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(usersList));
  } catch (e) {
    console.error('Failed to save users:', e);
  }
}

export async function authenticateUserAsync(loginOrEmail: string, passwordAttempt: string): Promise<UserProfile | null> {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ loginOrEmail, password: passwordAttempt }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data && data.user) {
        setAuthSession(data.user);
        return data.user;
      }
    }
  } catch (err) {
    console.warn('Server authentication fallback:', err);
  }

  // Fallback to local check if offline
  return authenticateUser(loginOrEmail, passwordAttempt);
}

export interface LockStatus {
  locked: boolean;
  canEdit: boolean;
  lockedByUserId?: string;
  lockedByUserName?: string;
  lockedByUserDepartment?: string;
  lockedAt?: string;
  message?: string;
}

export async function acquireDocumentLock(
  docId: string,
  user: UserProfile
): Promise<LockStatus> {
  try {
    const res = await fetch(`/api/registers/${encodeURIComponent(docId)}/lock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: user.id,
        userName: user.name,
        userDepartment: user.department,
      }),
    });
    const data = await res.json();
    if (!res.ok && res.status === 423) {
      return {
        locked: true,
        canEdit: false,
        lockedByUserId: data.lockedByUserId,
        lockedByUserName: data.lockedByUserName,
        lockedByUserDepartment: data.lockedByUserDepartment,
        lockedAt: data.lockedAt,
        message: data.message,
      };
    }
    return { locked: true, canEdit: true };
  } catch (err) {
    return { locked: false, canEdit: true };
  }
}

export async function releaseDocumentLock(docId: string, userId: string): Promise<void> {
  try {
    await fetch(`/api/registers/${encodeURIComponent(docId)}/lock`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
  } catch (err) {
    console.warn('Failed to release document lock:', err);
  }
}

export function authenticateUser(loginOrEmail: string, passwordAttempt: string): UserProfile | null {
  const usersList = getStoredUsers();
  const cleanLogin = loginOrEmail.trim().toLowerCase();
  const found = usersList.find(
    (u) =>
      u.login?.toLowerCase() === cleanLogin ||
      u.email?.toLowerCase() === cleanLogin ||
      u.role?.toLowerCase() === cleanLogin
  );

  if (!found) return null;

  const expectedPassword = found.password || 'kior2026';
  if (passwordAttempt === expectedPassword) {
    setAuthSession(found);
    return found;
  }
  return null;
}

export function getAuthSession(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_AUTH_SESSION);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // fallback
  }
  return null;
}

export function setAuthSession(user: UserProfile | null): void {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEY_AUTH_SESSION, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY_AUTH_SESSION);
    }
  } catch (e) {
    console.error('Failed to save auth session:', e);
  }
}

export function updateUserPassword(userId: string, newPassword: string): boolean {
  return updateUserProfile(userId, { password: newPassword });
}

export function updateUserProfile(userId: string, patch: Partial<UserProfile>): boolean {
  const usersList = getStoredUsers();
  const updated = usersList.map((u) => (u.id === userId ? { ...u, ...patch } : u));
  saveStoredUsers(updated);

  const current = getAuthSession();
  if (current && current.id === userId) {
    setAuthSession({ ...current, ...patch });
  }

  // Update in PostgreSQL
  fetch(`/api/users/${encodeURIComponent(userId)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  }).catch((err) => console.warn('Failed background user update to PostgreSQL:', err));

  return true;
}

export function addUserProfile(newUser: Omit<UserProfile, 'id'> & { id?: string }): UserProfile {
  const usersList = getStoredUsers();
  const id = newUser.id || `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const fullUser: UserProfile = {
    ...newUser,
    id,
    password: newUser.password || 'kior2026',
  };
  const updated = [...usersList, fullUser];
  saveStoredUsers(updated);

  // Post to PostgreSQL
  fetch('/api/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(fullUser),
  }).catch((err) => console.warn('Failed background user create to PostgreSQL:', err));

  return fullUser;
}

export function deleteUserProfile(userId: string): boolean {
  const usersList = getStoredUsers();
  const target = usersList.find((u) => u.id === userId);
  if (!target) return false;
  if (target.role === 'admin') {
    const adminCount = usersList.filter((u) => u.role === 'admin').length;
    if (adminCount <= 1) {
      throw new Error('Нельзя удалить единственного администратора системы.');
    }
  }
  const updated = usersList.filter((u) => u.id !== userId);
  saveStoredUsers(updated);

  // Delete from PostgreSQL
  fetch(`/api/users/${encodeURIComponent(userId)}`, {
    method: 'DELETE',
  }).catch((err) => console.warn('Failed background user delete from PostgreSQL:', err));

  return true;
}

export function getStoredUser(): UserProfile {
  const session = getAuthSession();
  if (session) return session;
  return INITIAL_USERS[0];
}

export function setStoredUser(user: UserProfile): void {
  setAuthSession(user);
}
