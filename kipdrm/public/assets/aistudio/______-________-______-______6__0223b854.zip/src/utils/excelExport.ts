/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import ExcelJS from 'exceljs';
import { RiskRegisterDocument, RiskClassId, RISK_CLASSES } from '../types/risk';
import { calculateRiskScore, formatNumberedList, getRatingDetails } from './calculations';
import { PROBABILITY_SCALE, TIME_IMPACT_SCALE, FINANCIAL_IMPACT_SCALE, NON_FINANCIAL_IMPACT_SCALE, MEASURE_GOALS } from './scales';

export async function generateRiskRegisterWorkbook(doc: RiskRegisterDocument): Promise<ExcelJS.Workbook> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'НАО «КИОР» — Портал Регистра рисков';
  workbook.lastModifiedBy = doc.header.coordinatorName || 'Координатор рисков';
  workbook.created = new Date(doc.createdAt || Date.now());
  workbook.modified = new Date();

  // Color palette
  const NAVY = '0B2545';
  const LIGHT_NAVY = '134074';
  const ICE_BLUE = 'EEF4F8';
  const BORDER_COLOR = 'D1D5DB';

  const defaultBorder: Partial<ExcelJS.Borders> = {
    top: { style: 'thin', color: { argb: BORDER_COLOR } },
    left: { style: 'thin', color: { argb: BORDER_COLOR } },
    bottom: { style: 'thin', color: { argb: BORDER_COLOR } },
    right: { style: 'thin', color: { argb: BORDER_COLOR } },
  };

  const headerFill: ExcelJS.Fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: LIGHT_NAVY },
  };

  const headerFont: Partial<ExcelJS.Font> = {
    name: 'Calibri',
    size: 11,
    bold: true,
    color: { argb: 'FFFFFF' },
  };

  const classSectionFill: ExcelJS.Fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'E2E8F0' },
  };

  const classSectionFont: Partial<ExcelJS.Font> = {
    name: 'Calibri',
    size: 11,
    bold: true,
    color: { argb: '1E293B' },
  };

  // ==========================================
  // SHEET 1: «Инструкция»
  // ==========================================
  const wsInst = workbook.addWorksheet('Инструкция', {
    views: [{ showGridLines: true }],
  });

  wsInst.columns = [
    { width: 5 },
    { width: 30 },
    { width: 50 },
    { width: 25 },
  ];

  wsInst.mergeCells('B2:D2');
  const instTitle = wsInst.getCell('B2');
  instTitle.value = 'НАО «КАЗАХСТАНСКИЙ ИНСТИТУТ ОБЩЕСТВЕННОГО РАЗВИТИЯ»';
  instTitle.font = { name: 'Calibri', size: 14, bold: true, color: { argb: NAVY } };
  instTitle.alignment = { horizontal: 'center', vertical: 'middle' };
  wsInst.getRow(2).height = 30;

  wsInst.mergeCells('B3:D3');
  const instSub = wsInst.getCell('B3');
  instSub.value = 'РЕГИСТР РИСКОВ И ОТЧЕТ О РЕАЛИЗОВАННЫХ РИСКАХ';
  instSub.font = { name: 'Calibri', size: 12, bold: true, color: { argb: LIGHT_NAVY } };
  instSub.alignment = { horizontal: 'center', vertical: 'middle' };
  wsInst.getRow(3).height = 24;

  // Header inputs in C4, C5, C6 (as specified)
  wsInst.getCell('B4').value = 'Структурное подразделение:';
  wsInst.getCell('B4').font = { bold: true };
  wsInst.getCell('C4').value = doc.header.department;
  wsInst.getCell('C4').font = { bold: true, color: { argb: NAVY } };

  wsInst.getCell('B5').value = 'Отчетный период:';
  wsInst.getCell('B5').font = { bold: true };
  wsInst.getCell('C5').value = doc.header.periodString;
  wsInst.getCell('C5').font = { bold: true, color: { argb: NAVY } };

  wsInst.getCell('B6').value = 'Координатор по рискам (ФИО, должность):';
  wsInst.getCell('B6').font = { bold: true };
  wsInst.getCell('C6').value = `${doc.header.coordinatorName}, ${doc.header.coordinatorPosition}`;
  wsInst.getCell('C6').font = { bold: true, color: { argb: NAVY } };

  wsInst.getCell('B7').value = 'Курирующий заместитель председателя:';
  wsInst.getCell('B7').font = { bold: true };
  wsInst.getCell('C7').value = doc.header.curatingDeputyName || 'Сапарбаев Е. Б.';

  // Information box
  const notesStart = 9;
  const notes = [
    '1. Регистр рисков составляется ежеквартально в соответствии с Политикой управления рисками НАО «КИОР».',
    '2. Срок подачи проекта Регистра рисков менеджеру по рискам: не позднее 30 ноября (до 23:59).',
    '3. Срок предоставления утвержденного курирующим заместителем Регистра: не позднее 3-го декабря.',
    '4. Присвоение номеров рисков осуществляется строго по утвержденной Номенклатуре (формат: 1-С-XX, 2-Ф-XX, 3-П-XX, 4-К-XX, 5-О-XX). Буквы кириллические!',
    '5. Для всех рисков с рейтингом 0,9 (высокая) и 1,0 (крайне высокая) обязательна к заполнению вкладка «Панель КПР».',
    '6. В отчете о реализованных рисках при отсутствии инцидентов в отчетном периоде обязательно проставляется отметка «Случаев не было».',
  ];

  notes.forEach((text, i) => {
    const rowIdx = notesStart + i;
    wsInst.mergeCells(`B${rowIdx}:D${rowIdx}`);
    const cell = wsInst.getCell(`B${rowIdx}`);
    cell.value = text;
    cell.font = { italic: true, size: 10, color: { argb: '475569' } };
  });

  // Prepare risks grouped by class
  const classOrder: RiskClassId[] = ['1-С', '2-Ф', '3-П', '4-К', '5-О'];

  // Map to hold row index in Part 1 for each risk so Part 2 and Part 3 stay exactly aligned
  const riskRowMap = new Map<string, number>();

  // ==========================================
  // SHEET 2: «Регистр Ч.1» (Inherent risk)
  // ==========================================
  const wsPart1 = workbook.addWorksheet('Регистр Ч.1', {
    views: [{ state: 'frozen', xSplit: 2, ySplit: 3, showGridLines: true }],
  });

  wsPart1.columns = [
    { key: 'riskNumber', width: 14 }, // A
    { key: 'name', width: 38 }, // B
    { key: 'factors', width: 35 }, // C
    { key: 'consequences', width: 35 }, // D
    { key: 'ownerUnit', width: 28 }, // E
    { key: 'prob', width: 14 }, // F
    { key: 'time', width: 14 }, // G
    { key: 'impact', width: 14 }, // H
    { key: 'damage', width: 16 }, // I
    { key: 'score', width: 14 }, // J
    { key: 'rating', width: 22 }, // K
  ];

  // Header rows
  wsPart1.mergeCells('A1:K1');
  const p1Header = wsPart1.getCell('A1');
  p1Header.value = `РЕГИСТР РИСКОВ (ЧАСТЬ 1. ОЦЕНКА ПРИСУЩЕГО РИСКА) — ${doc.header.department.toUpperCase()} (${doc.header.periodString})`;
  p1Header.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  p1Header.alignment = { horizontal: 'center', vertical: 'middle' };
  wsPart1.getRow(1).height = 28;

  const p1ColHeaders = [
    'Номер риска',
    'Наименование риска',
    'Риск-факторы (источники/причины)',
    'Описание возможных последствий',
    'Структурное подразделение — владелец риска',
    'Балл вероятности (1–5)',
    'Балл времени влияния (1–3)',
    'Балл влияния (1–5)',
    'Размер ущерба (тыс. тенге)',
    'Балл значимости',
    'Рейтинг риска',
  ];

  const p1SubHeaders = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '10 = (6+7)×8', '11'
  ];

  const row2 = wsPart1.getRow(2);
  row2.values = p1ColHeaders;
  row2.height = 32;
  row2.eachCell((cell) => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = defaultBorder;
  });

  const row3 = wsPart1.getRow(3);
  row3.values = p1SubHeaders;
  row3.height = 18;
  row3.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '334155' } };
    cell.font = { name: 'Calibri', size: 9, italic: true, color: { argb: 'FFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = defaultBorder;
  });

  let currentRowP1 = 4;

  classOrder.forEach((cId) => {
    const classInfo = RISK_CLASSES[cId];
    const risksInClass = doc.risks.filter((r) => r.classId === cId);

    // Section header
    wsPart1.mergeCells(`A${currentRowP1}:K${currentRowP1}`);
    const secCell = wsPart1.getCell(`A${currentRowP1}`);
    secCell.value = classInfo.title;
    secCell.fill = classSectionFill;
    secCell.font = classSectionFont;
    secCell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    secCell.border = defaultBorder;
    wsPart1.getRow(currentRowP1).height = 24;
    currentRowP1++;

    // Risks in this class (at least one row, or actual items)
    if (risksInClass.length === 0) {
      wsPart1.mergeCells(`A${currentRowP1}:K${currentRowP1}`);
      const emptyCell = wsPart1.getCell(`A${currentRowP1}`);
      emptyCell.value = 'В данном классе рисков в отчетном периоде риски не идентифицированы';
      emptyCell.font = { italic: true, color: { argb: '94A3B8' } };
      emptyCell.alignment = { horizontal: 'center', vertical: 'middle' };
      emptyCell.border = defaultBorder;
      wsPart1.getRow(currentRowP1).height = 20;
      currentRowP1++;
    } else {
      risksInClass.forEach((risk) => {
        const rIndex = currentRowP1;
        riskRowMap.set(risk.id, rIndex);

        const rRow = wsPart1.getRow(rIndex);
        const p = risk.probability || 1;
        const t = risk.timeImpact || 1;
        const i = risk.impact || 1;
        const calcScore = (p + t) * i;
        const rating = getRatingDetails(calcScore);

        rRow.getCell(1).value = risk.riskNumber;
        rRow.getCell(2).value = risk.name;
        rRow.getCell(3).value = formatNumberedList(risk.factors);
        rRow.getCell(4).value = formatNumberedList(risk.consequences);
        rRow.getCell(5).value = risk.ownerUnit || doc.header.department;
        rRow.getCell(6).value = p;
        rRow.getCell(7).value = t;
        rRow.getCell(8).value = i;
        rRow.getCell(9).value = risk.damageThousandKzt || 0;

        // Excel formula for score: =(F{row}+G{row})*H{row}
        rRow.getCell(10).value = {
          formula: `=(F${rIndex}+G${rIndex})*H${rIndex}`,
          result: calcScore,
        };

        // Excel formula for rating
        rRow.getCell(11).value = {
          formula: `=IF(J${rIndex}>=28,"1,0 крайне высокая",IF(J${rIndex}>=15,"0,9 высокая",IF(J${rIndex}>=8,"0,8 средняя",IF(J${rIndex}>=1,"0,6 низкая","0,5 крайне низкая"))))`,
          result: rating.ratingText,
        };

        // Alignments & Styles
        rRow.getCell(1).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(2).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(3).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(4).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(5).alignment = { horizontal: 'center', vertical: 'top', wrapText: true };
        rRow.getCell(6).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(7).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(8).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(9).alignment = { horizontal: 'right', vertical: 'top' };
        rRow.getCell(10).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(11).alignment = { horizontal: 'center', vertical: 'top' };

        rRow.getCell(10).font = { bold: true };
        rRow.getCell(11).font = { bold: true, color: { argb: rating.colorHex.replace('#', '') } };

        for (let col = 1; col <= 11; col++) {
          rRow.getCell(col).border = defaultBorder;
        }

        rRow.height = Math.max(45, (Math.max(risk.factors.length, risk.consequences.length) * 18));
        currentRowP1++;
      });
    }
  });

  // ==========================================
  // SHEET 3: «Регистр Ч.2» (Measures)
  // Rows strictly aligned with Ч.1
  // ==========================================
  const wsPart2 = workbook.addWorksheet('Регистр Ч.2', {
    views: [{ state: 'frozen', xSplit: 2, ySplit: 3, showGridLines: true }],
  });

  wsPart2.columns = [
    { key: 'riskNumber', width: 14 }, // A
    { key: 'name', width: 34 }, // B
    { key: 'measureName', width: 38 }, // C
    { key: 'goal', width: 14 }, // D
    { key: 'cost', width: 16 }, // E
    { key: 'costBenefit', width: 28 }, // F
    { key: 'deadline', width: 18 }, // G
    { key: 'form', width: 26 }, // H
    { key: 'unit', width: 26 }, // I
    { key: 'fact', width: 20 }, // J
  ];

  wsPart2.mergeCells('A1:J1');
  const p2Header = wsPart2.getCell('A1');
  p2Header.value = `РЕГИСТР РИСКОВ (ЧАСТЬ 2. МЕРОПРИЯТИЯ ПО УПРАВЛЕНИЮ РИСКОМ) — ${doc.header.department.toUpperCase()}`;
  p2Header.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  p2Header.alignment = { horizontal: 'center', vertical: 'middle' };
  wsPart2.getRow(1).height = 28;

  const p2ColHeaders = [
    'Номер риска',
    'Наименование риска',
    'Наименование мероприятия по управлению риском',
    'Цель (А/Б/В/Г)',
    'Оценочная стоимость, тыс. ₸',
    'Сопоставление затрат с результатами',
    'Срок реализации',
    'Форма завершения',
    'Ответственное подразделение',
    'Факт выполнения',
  ];

  const p2SubHeaders = [
    '1 (ссылка на Ч.1)', '2 (ссылка на Ч.1)', '3', '4', '5', '6', '7', '8', '9', '10'
  ];

  const row2P2 = wsPart2.getRow(2);
  row2P2.values = p2ColHeaders;
  row2P2.height = 32;
  row2P2.eachCell((cell) => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = defaultBorder;
  });

  const row3P2 = wsPart2.getRow(3);
  row3P2.values = p2SubHeaders;
  row3P2.height = 18;
  row3P2.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '334155' } };
    cell.font = { name: 'Calibri', size: 9, italic: true, color: { argb: 'FFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = defaultBorder;
  });

  let currentRowP2 = 4;

  classOrder.forEach((cId) => {
    const classInfo = RISK_CLASSES[cId];
    const risksInClass = doc.risks.filter((r) => r.classId === cId);

    // Section header
    wsPart2.mergeCells(`A${currentRowP2}:J${currentRowP2}`);
    const secCell = wsPart2.getCell(`A${currentRowP2}`);
    secCell.value = classInfo.title;
    secCell.fill = classSectionFill;
    secCell.font = classSectionFont;
    secCell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    secCell.border = defaultBorder;
    wsPart2.getRow(currentRowP2).height = 24;
    currentRowP2++;

    if (risksInClass.length === 0) {
      wsPart2.mergeCells(`A${currentRowP2}:J${currentRowP2}`);
      const emptyCell = wsPart2.getCell(`A${currentRowP2}`);
      emptyCell.value = 'В данном классе рисков в отчетном периоде риски не идентифицированы';
      emptyCell.font = { italic: true, color: { argb: '94A3B8' } };
      emptyCell.alignment = { horizontal: 'center', vertical: 'middle' };
      emptyCell.border = defaultBorder;
      wsPart2.getRow(currentRowP2).height = 20;
      currentRowP2++;
    } else {
      risksInClass.forEach((risk) => {
        const rIndex = currentRowP2;
        const rRow = wsPart2.getRow(rIndex);

        // Pull risk number and name BY ROW from Part 1 via Excel formulas
        rRow.getCell(1).value = {
          formula: `='Регистр Ч.1'!A${rIndex}`,
          result: risk.riskNumber,
        };
        rRow.getCell(2).value = {
          formula: `='Регистр Ч.1'!B${rIndex}`,
          result: risk.name,
        };

        // Serialize multiple measures matching example file
        const measures = risk.measures || [];
        const measureNames = measures.map((m) => m.name);
        const goals = measures.map((m) => m.goal);
        const costs = measures.map((m) => `${m.estimatedCost || 0}`);
        const costBenefits = measures.map((m) => m.costBenefitAnalysis || '—');
        const deadlines = measures.map((m) => m.deadline);
        const forms = measures.map((m) => m.completionForm);
        const units = measures.map((m) => m.responsibleUnit || doc.header.department);
        const statuses = measures.map((m) => m.status);

        rRow.getCell(3).value = formatNumberedList(measureNames);
        rRow.getCell(4).value = formatNumberedList(goals);
        rRow.getCell(5).value = formatNumberedList(costs);
        rRow.getCell(6).value = formatNumberedList(costBenefits);
        rRow.getCell(7).value = formatNumberedList(deadlines);
        rRow.getCell(8).value = formatNumberedList(forms);
        rRow.getCell(9).value = formatNumberedList(units);
        rRow.getCell(10).value = formatNumberedList(statuses);

        rRow.getCell(1).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(2).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(3).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(4).alignment = { horizontal: 'center', vertical: 'top', wrapText: true };
        rRow.getCell(5).alignment = { horizontal: 'right', vertical: 'top', wrapText: true };
        rRow.getCell(6).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(7).alignment = { horizontal: 'center', vertical: 'top', wrapText: true };
        rRow.getCell(8).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(9).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(10).alignment = { horizontal: 'center', vertical: 'top', wrapText: true };

        for (let col = 1; col <= 10; col++) {
          rRow.getCell(col).border = defaultBorder;
        }

        rRow.height = Math.max(45, (Math.max(1, measures.length) * 22));
        currentRowP2++;
      });
    }
  });

  // ==========================================
  // SHEET 4: «Регистр Ч.3» (Residual risk)
  // Rows strictly aligned with Ч.1
  // ==========================================
  const wsPart3 = workbook.addWorksheet('Регистр Ч.3', {
    views: [{ state: 'frozen', xSplit: 2, ySplit: 3, showGridLines: true }],
  });

  wsPart3.columns = [
    { key: 'riskNumber', width: 14 }, // A
    { key: 'name', width: 34 }, // B
    { key: 'inherentScore', width: 15 }, // C
    { key: 'inherentRating', width: 20 }, // D
    { key: 'resProb', width: 14 }, // E
    { key: 'resTime', width: 14 }, // F
    { key: 'resImpact', width: 14 }, // G
    { key: 'resDamage', width: 16 }, // H
    { key: 'resScore', width: 14 }, // I
    { key: 'resRating', width: 22 }, // J
    { key: 'effectiveness', width: 28 }, // K
  ];

  wsPart3.mergeCells('A1:K1');
  const p3Header = wsPart3.getCell('A1');
  p3Header.value = `РЕГИСТР РИСКОВ (ЧАСТЬ 3. ОЦЕНКА ОСТАТОЧНОГО РИСКА И ЭФФЕКТИВНОСТИ) — ${doc.header.department.toUpperCase()}`;
  p3Header.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  p3Header.alignment = { horizontal: 'center', vertical: 'middle' };
  wsPart3.getRow(1).height = 28;

  const p3ColHeaders = [
    'Номер риска',
    'Наименование риска',
    'Присущий балл',
    'Присущий рейтинг',
    'Остаточная вероятность (1–5)',
    'Остаточное время (1–3)',
    'Остаточное влияние (1–5)',
    'Остаточный ущерб (тыс. ₸)',
    'Остаточный балл',
    'Остаточный рейтинг',
    'Оценка эффективности мероприятий',
  ];

  const p3SubHeaders = [
    '1 (из Ч.1)', '2 (из Ч.1)', '3 (из Ч.1)', '4 (из Ч.1)', '5', '6', '7', '8', '9 = (5+6)×7', '10', '11 = f(3, 9)'
  ];

  const row2P3 = wsPart3.getRow(2);
  row2P3.values = p3ColHeaders;
  row2P3.height = 32;
  row2P3.eachCell((cell) => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = defaultBorder;
  });

  const row3P3 = wsPart3.getRow(3);
  row3P3.values = p3SubHeaders;
  row3P3.height = 18;
  row3P3.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '334155' } };
    cell.font = { name: 'Calibri', size: 9, italic: true, color: { argb: 'FFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = defaultBorder;
  });

  let currentRowP3 = 4;

  classOrder.forEach((cId) => {
    const classInfo = RISK_CLASSES[cId];
    const risksInClass = doc.risks.filter((r) => r.classId === cId);

    // Section header
    wsPart3.mergeCells(`A${currentRowP3}:K${currentRowP3}`);
    const secCell = wsPart3.getCell(`A${currentRowP3}`);
    secCell.value = classInfo.title;
    secCell.fill = classSectionFill;
    secCell.font = classSectionFont;
    secCell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    secCell.border = defaultBorder;
    wsPart3.getRow(currentRowP3).height = 24;
    currentRowP3++;

    if (risksInClass.length === 0) {
      wsPart3.mergeCells(`A${currentRowP3}:K${currentRowP3}`);
      const emptyCell = wsPart3.getCell(`A${currentRowP3}`);
      emptyCell.value = 'В данном классе рисков в отчетном периоде риски не идентифицированы';
      emptyCell.font = { italic: true, color: { argb: '94A3B8' } };
      emptyCell.alignment = { horizontal: 'center', vertical: 'middle' };
      emptyCell.border = defaultBorder;
      wsPart3.getRow(currentRowP3).height = 20;
      currentRowP3++;
    } else {
      risksInClass.forEach((risk) => {
        const rIndex = currentRowP3;
        const rRow = wsPart3.getRow(rIndex);

        const inhScore = calculateRiskScore(risk.probability, risk.timeImpact, risk.impact);
        const inhRating = getRatingDetails(inhScore);

        const rp = risk.residualProbability || risk.probability || 1;
        const rt = risk.residualTimeImpact || risk.timeImpact || 1;
        const ri = risk.residualImpact || risk.impact || 1;
        const resScore = (rp + rt) * ri;
        const resRating = getRatingDetails(resScore);

        let effText = 'Риск не снижен';
        if (resScore > inhScore) effText = 'Ошибка: остаточный выше присущего';
        else if (resScore < inhScore) effText = `Эффективно: ${inhScore} → ${resScore}`;

        // Pull risk number, name, inherent score, inherent rating from Part 1 BY ROW
        rRow.getCell(1).value = {
          formula: `='Регистр Ч.1'!A${rIndex}`,
          result: risk.riskNumber,
        };
        rRow.getCell(2).value = {
          formula: `='Регистр Ч.1'!B${rIndex}`,
          result: risk.name,
        };
        rRow.getCell(3).value = {
          formula: `='Регистр Ч.1'!J${rIndex}`,
          result: inhScore,
        };
        rRow.getCell(4).value = {
          formula: `='Регистр Ч.1'!K${rIndex}`,
          result: inhRating.ratingText,
        };

        rRow.getCell(5).value = rp;
        rRow.getCell(6).value = rt;
        rRow.getCell(7).value = ri;
        rRow.getCell(8).value = risk.residualDamageThousandKzt || 0;

        // Residual score formula
        rRow.getCell(9).value = {
          formula: `=(E${rIndex}+F${rIndex})*G${rIndex}`,
          result: resScore,
        };

        // Residual rating formula
        rRow.getCell(10).value = {
          formula: `=IF(I${rIndex}>=28,"1,0 крайне высокая",IF(I${rIndex}>=15,"0,9 высокая",IF(I${rIndex}>=8,"0,8 средняя",IF(I${rIndex}>=1,"0,6 низкая","0,5 крайне низкая"))))`,
          result: resRating.ratingText,
        };

        // Effectiveness formula:
        rRow.getCell(11).value = {
          formula: `=IF(I${rIndex}>C${rIndex},"Ошибка: остаточный выше присущего",IF(I${rIndex}<C${rIndex},CONCATENATE("Эффективно: ",C${rIndex}," → ",I${rIndex}),"Риск не снижен"))`,
          result: effText,
        };

        rRow.getCell(1).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(2).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(3).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(4).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(5).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(6).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(7).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(8).alignment = { horizontal: 'right', vertical: 'top' };
        rRow.getCell(9).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(10).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(11).alignment = { horizontal: 'center', vertical: 'top' };

        rRow.getCell(9).font = { bold: true };
        rRow.getCell(10).font = { bold: true, color: { argb: resRating.colorHex.replace('#', '') } };
        rRow.getCell(11).font = {
          bold: true,
          color: { argb: resScore > inhScore ? 'DC2626' : resScore < inhScore ? '16A34A' : 'D97706' },
        };

        for (let col = 1; col <= 11; col++) {
          rRow.getCell(col).border = defaultBorder;
        }

        rRow.height = 36;
        currentRowP3++;
      });
    }
  });

  // ==========================================
  // SHEET 5: «Панель КПР»
  // ==========================================
  const wsKpr = workbook.addWorksheet('Панель КПР', {
    views: [{ state: 'frozen', xSplit: 0, ySplit: 3, showGridLines: true }],
  });

  wsKpr.columns = [
    { key: 'num', width: 6 },
    { key: 'riskNum', width: 14 },
    { key: 'name', width: 34 },
    { key: 'score', width: 12 },
    { key: 'zone', width: 16 },
    { key: 'factors', width: 32 },
    { key: 'consequences', width: 32 },
    { key: 'leading', width: 28 },
    { key: 'lagging', width: 28 },
    { key: 'threshold', width: 26 },
    { key: 'measure', width: 32 },
  ];

  wsKpr.mergeCells('A1:K1');
  const kprHeader = wsKpr.getCell('A1');
  kprHeader.value = `ПАНЕЛЬ КЛЮЧЕВЫХ ПОКАЗАТЕЛЕЙ РИСКА (КПР) — ${doc.header.department.toUpperCase()}`;
  kprHeader.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  kprHeader.alignment = { horizontal: 'center', vertical: 'middle' };
  wsKpr.getRow(1).height = 28;

  const kprColHeaders = [
    '№',
    'Номер риска',
    'Наименование риска',
    'Балл',
    'Зона карты рисков',
    'Риск-факторы',
    'Возможные последствия',
    'КПР опережающий',
    'КПР итоговый',
    'Пороговое значение КПР',
    'Мероприятие по управлению риском',
  ];

  const row2Kpr = wsKpr.getRow(2);
  row2Kpr.values = kprColHeaders;
  row2Kpr.height = 30;
  row2Kpr.eachCell((cell) => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = defaultBorder;
  });

  const row3Kpr = wsKpr.getRow(3);
  row3Kpr.values = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'];
  row3Kpr.height = 18;
  row3Kpr.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '334155' } };
    cell.font = { name: 'Calibri', size: 9, italic: true, color: { argb: 'FFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = defaultBorder;
  });

  let currentKprRow = 4;
  (doc.kprList || []).forEach((kpr, idx) => {
    const parentRisk = doc.risks.find((r) => r.riskNumber === kpr.riskNumber);
    const score = parentRisk
      ? calculateRiskScore(parentRisk.probability, parentRisk.timeImpact, parentRisk.impact)
      : 20;
    const ratingInfo = getRatingDetails(score);

    const rRow = wsKpr.getRow(currentKprRow);
    rRow.getCell(1).value = idx + 1;
    rRow.getCell(2).value = kpr.riskNumber;
    rRow.getCell(3).value = parentRisk ? parentRisk.name : '—';
    rRow.getCell(4).value = score;
    rRow.getCell(5).value = ratingInfo.zone;
    rRow.getCell(6).value = parentRisk ? formatNumberedList(parentRisk.factors) : '—';
    rRow.getCell(7).value = parentRisk ? formatNumberedList(parentRisk.consequences) : '—';
    rRow.getCell(8).value = kpr.leadingKpr;
    rRow.getCell(9).value = kpr.laggingKpr;
    rRow.getCell(10).value = kpr.thresholdValue;
    rRow.getCell(11).value = kpr.managementMeasure;

    rRow.getCell(1).alignment = { horizontal: 'center', vertical: 'top' };
    rRow.getCell(2).alignment = { horizontal: 'center', vertical: 'top' };
    rRow.getCell(3).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(4).alignment = { horizontal: 'center', vertical: 'top' };
    rRow.getCell(5).alignment = { horizontal: 'center', vertical: 'top' };
    rRow.getCell(6).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(7).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(8).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(9).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(10).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
    rRow.getCell(11).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };

    rRow.getCell(4).font = { bold: true };
    rRow.getCell(5).font = { bold: true, color: { argb: ratingInfo.colorHex.replace('#', '') } };

    for (let col = 1; col <= 11; col++) {
      rRow.getCell(col).border = defaultBorder;
    }

    rRow.height = 55;
    currentKprRow++;
  });

  if ((doc.kprList || []).length === 0) {
    wsKpr.mergeCells(`A4:K4`);
    const empty = wsKpr.getCell('A4');
    empty.value = 'В отчетном периоде отсутствуют риски высокой и крайне высокой зоны (рейтинг ≥ 0,9)';
    empty.font = { italic: true, color: { argb: '94A3B8' } };
    empty.alignment = { horizontal: 'center', vertical: 'middle' };
    empty.border = defaultBorder;
    wsKpr.getRow(4).height = 25;
  }

  // ==========================================
  // SHEET 6: «Реализованные риски» (Appendix 3)
  // ==========================================
  const wsReal = workbook.addWorksheet('Реализованные риски', {
    views: [{ state: 'frozen', xSplit: 0, ySplit: 3, showGridLines: true }],
  });

  wsReal.columns = [
    { key: 'num', width: 6 },
    { key: 'date', width: 14 },
    { key: 'desc', width: 36 },
    { key: 'location', width: 24 },
    { key: 'causes', width: 28 },
    { key: 'initial', width: 22 },
    { key: 'final', width: 22 },
    { key: 'measures', width: 28 },
    { key: 'eff', width: 24 },
    { key: 'dept', width: 24 },
  ];

  wsReal.mergeCells('A1:J1');
  const realHeader = wsReal.getCell('A1');
  realHeader.value = `ОТЧЕТ О РЕАЛИЗОВАННЫХ РИСКАХ (ПРИЛОЖЕНИЕ 3) — ${doc.header.department.toUpperCase()} (${doc.header.periodString})`;
  realHeader.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  realHeader.alignment = { horizontal: 'center', vertical: 'middle' };
  wsReal.getRow(1).height = 28;

  const realColHeaders = [
    '№ п/п',
    'Дата фиксации',
    'Детальное описание реализованного события (с номером риска)',
    'Место наступления',
    'Причины реализации',
    'Ущерб первоначальный',
    'Ущерб окончательный',
    'Принятые меры',
    'Оценка эффективности',
    'Структурное подразделение',
  ];

  const row2Real = wsReal.getRow(2);
  row2Real.values = realColHeaders;
  row2Real.height = 32;
  row2Real.eachCell((cell) => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = defaultBorder;
  });

  const row3Real = wsReal.getRow(3);
  row3Real.values = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
  row3Real.height = 18;
  row3Real.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '334155' } };
    cell.font = { name: 'Calibri', size: 9, italic: true, color: { argb: 'FFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = defaultBorder;
  });

  let currentRealRow = 4;
  classOrder.forEach((cId) => {
    const classInfo = RISK_CLASSES[cId];
    const section = doc.realizedReport?.[cId];

    // Section header
    wsReal.mergeCells(`A${currentRealRow}:J${currentRealRow}`);
    const secCell = wsReal.getCell(`A${currentRealRow}`);
    secCell.value = `${classInfo.title} ${section?.hasNoEvents ? '— [СЛУЧАЕВ НЕ БЫЛО]' : ''}`;
    secCell.fill = classSectionFill;
    secCell.font = classSectionFont;
    secCell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    secCell.border = defaultBorder;
    wsReal.getRow(currentRealRow).height = 24;
    currentRealRow++;

    if (section?.hasNoEvents || !section?.events || section.events.length === 0) {
      wsReal.mergeCells(`A${currentRealRow}:J${currentRealRow}`);
      const empty = wsReal.getCell(`A${currentRealRow}`);
      empty.value = 'В отчетном периоде событий реализовавшихся рисков не зафиксировано («Случаев не было»)';
      empty.font = { italic: true, color: { argb: '64748B' } };
      empty.alignment = { horizontal: 'center', vertical: 'middle' };
      empty.border = defaultBorder;
      wsReal.getRow(currentRealRow).height = 20;
      currentRealRow++;
    } else {
      section.events.forEach((ev, idx) => {
        const rRow = wsReal.getRow(currentRealRow);
        rRow.getCell(1).value = idx + 1;
        rRow.getCell(2).value = ev.detectionDate;
        rRow.getCell(3).value = ev.description;
        rRow.getCell(4).value = ev.occurrenceLocation;
        rRow.getCell(5).value = ev.causes;
        rRow.getCell(6).value = ev.initialDamage;
        rRow.getCell(7).value = ev.finalDamage;
        rRow.getCell(8).value = ev.takenMeasures;
        rRow.getCell(9).value = ev.effectivenessEvaluation;
        rRow.getCell(10).value = ev.department || doc.header.department;

        rRow.getCell(1).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(2).alignment = { horizontal: 'center', vertical: 'top' };
        rRow.getCell(3).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(4).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(5).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(6).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(7).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(8).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(9).alignment = { horizontal: 'left', vertical: 'top', wrapText: true };
        rRow.getCell(10).alignment = { horizontal: 'center', vertical: 'top', wrapText: true };

        for (let col = 1; col <= 10; col++) {
          rRow.getCell(col).border = defaultBorder;
        }

        rRow.height = 45;
        currentRealRow++;
      });
    }
  });

  // ==========================================
  // SHEET 7: «Шкалы оценки»
  // ==========================================
  const wsScales = workbook.addWorksheet('Шкалы оценки', {
    views: [{ showGridLines: true }],
  });

  wsScales.columns = [
    { width: 8 },
    { width: 22 },
    { width: 30 },
    { width: 55 },
  ];

  wsScales.mergeCells('A1:D1');
  const scalesHead = wsScales.getCell('A1');
  scalesHead.value = 'КРИТЕРИИ И ШКАЛЫ ОЦЕНКИ РИСКОВ (ИЗ ПАМЯТКИ НАО «КИОР»)';
  scalesHead.font = { name: 'Calibri', size: 12, bold: true, color: { argb: NAVY } };
  scalesHead.alignment = { horizontal: 'center', vertical: 'middle' };
  wsScales.getRow(1).height = 26;

  let sRow = 3;

  const addScaleTable = (title: string, data: typeof PROBABILITY_SCALE) => {
    wsScales.mergeCells(`A${sRow}:D${sRow}`);
    const tCell = wsScales.getCell(`A${sRow}`);
    tCell.value = title;
    tCell.font = { bold: true, size: 11, color: { argb: LIGHT_NAVY } };
    tCell.fill = classSectionFill;
    wsScales.getRow(sRow).height = 22;
    sRow++;

    const header = wsScales.getRow(sRow);
    header.values = ['Балл', 'Уровень', 'Частота / Критерий', 'Детальное описание'];
    header.height = 20;
    header.eachCell((c) => {
      c.fill = headerFill;
      c.font = headerFont;
      c.alignment = { horizontal: 'center', vertical: 'middle' };
      c.border = defaultBorder;
    });
    sRow++;

    data.forEach((lvl) => {
      const row = wsScales.getRow(sRow);
      row.values = [lvl.score, lvl.title, lvl.description, lvl.detail];
      row.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell(2).alignment = { horizontal: 'left', vertical: 'middle' };
      row.getCell(3).alignment = { horizontal: 'left', vertical: 'middle' };
      row.getCell(4).alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
      row.height = 28;
      for (let c = 1; c <= 4; c++) row.getCell(c).border = defaultBorder;
      sRow++;
    });

    sRow += 2;
  };

  addScaleTable('Таблица 1. Шкала оценки вероятности наступления риска', PROBABILITY_SCALE);
  addScaleTable('Таблица 2. Шкала времени влияния риска на деятельность института', TIME_IMPACT_SCALE);
  addScaleTable('Таблица 3. Шкала финансового влияния (размер материального ущерба)', FINANCIAL_IMPACT_SCALE);
  addScaleTable('Таблица 4. Шкала нефинансового влияния (репутация, правовые санкции, госзадание)', NON_FINANCIAL_IMPACT_SCALE);

  return workbook;
}

/**
 * Generates file buffer and triggers direct browser download
 */
export async function downloadRiskRegisterExcel(doc: RiskRegisterDocument): Promise<void> {
  const workbook = await generateRiskRegisterWorkbook(doc);
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const deptSanitized = (doc.header.department || 'Подразделение')
    .replace(/[^\w\u0400-\u04FF]/g, '_')
    .replace(/_+/g, '_');
  const filename = `Регистр_рисков_${deptSanitized}_${doc.header.quarter}_квартал_${doc.header.year}.xlsx`;

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
