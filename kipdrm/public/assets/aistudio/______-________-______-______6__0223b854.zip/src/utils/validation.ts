/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RiskRegisterDocument, ValidationItem, RiskClassId } from '../types/risk';
import { calculateRiskScore } from './calculations';

// Cyrillic uppercase letters allowed
const CYRILLIC_LETTERS = ['С', 'Ф', 'П', 'К', 'О'];

const CLASS_REGEX_MAP: Record<RiskClassId, RegExp> = {
  '1-С': /^1-С-\d+$/,
  '2-Ф': /^2-Ф-\d+$/,
  '3-П': /^3-П-\d+$/,
  '4-К': /^4-К-\d+$/,
  '5-О': /^5-О-\d+$/,
};

export function validateRegister(doc: RiskRegisterDocument): {
  isValid: boolean;
  blockingErrors: ValidationItem[];
  warnings: ValidationItem[];
  checklistStatus: Record<string, boolean>;
} {
  const blocking: ValidationItem[] = [];
  const warnings: ValidationItem[] = [];
  let itemCounter = 0;

  const addBlocking = (step: number, section: string, message: string, recommendation?: string, riskNumber?: string) => {
    itemCounter++;
    blocking.push({
      id: `err_${itemCounter}`,
      type: 'blocking',
      step,
      section,
      riskNumber,
      message,
      recommendation,
    });
  };

  const addWarning = (step: number, section: string, message: string, recommendation?: string, riskNumber?: string) => {
    itemCounter++;
    warnings.push({
      id: `warn_${itemCounter}`,
      type: 'warning',
      step,
      section,
      riskNumber,
      message,
      recommendation,
    });
  };

  // 1. Step 0: Header validation
  if (!doc.header.department?.trim()) {
    addBlocking(0, 'Инструкция', 'Не указано структурное подразделение — владелец регистра.');
  }
  if (!doc.header.coordinatorName?.trim()) {
    addBlocking(0, 'Инструкция', 'Не указано ФИО координатора по управлению рисками.');
  }
  if (!doc.header.coordinatorPosition?.trim()) {
    addBlocking(0, 'Инструкция', 'Не указана должность координатора.');
  }
  if (!doc.header.periodString?.trim()) {
    addBlocking(0, 'Инструкция', 'Не сформирован отчетный период.');
  }

  // 2. Step 1: Part 1 - Risks checks
  if (!doc.risks || doc.risks.length === 0) {
    addBlocking(1, 'Регистр Ч.1', 'В регистре не внесено ни одного риска. Требуется заполнить хотя бы один риск.');
  }

  const seenNumbers = new Set<string>();
  const allRiskNumbersInDoc = new Set<string>();

  doc.risks.forEach((risk, index) => {
    const rNum = (risk.riskNumber || '').trim();
    const classId = risk.classId;

    if (!rNum) {
      addBlocking(1, 'Регистр Ч.1', `У риска №${index + 1} не заполнен номер риска.`);
      return;
    }

    // Check duplicate
    if (seenNumbers.has(rNum)) {
      addBlocking(1, 'Регистр Ч.1', `Дубликат номера риска: «${rNum}». Номера рисков в регистре должны быть уникальны.`, undefined, rNum);
    } else {
      seenNumbers.add(rNum);
      allRiskNumbersInDoc.add(rNum);
    }

    // General pattern check: ^[1-5]-[СФПКО]-\d+$
    // Note: check for accidental Latin letters (e.g. C, F, P, K, O in Latin)
    const latinCheck = /[CFPKOcfkpo]/;
    if (latinCheck.test(rNum)) {
      addBlocking(
        1,
        'Регистр Ч.1',
        `Номер риска «${rNum}» содержит латинские буквы. В номенклатуре допускаются только кириллические буквы (С, Ф, П, К, О).`,
        'Замените латинские буквы на русские.',
        rNum
      );
    }

    const classRegex = CLASS_REGEX_MAP[classId];
    if (!classRegex || !classRegex.test(rNum)) {
      addBlocking(
        1,
        'Регистр Ч.1',
        `Номер «${rNum}» не соответствует формату класса ${classId} (ожидается формат вроде «${classId}-01»).`,
        `Для класса ${classId} номер должен начинаться с ${classId}-, например: ${classId}-01.`,
        rNum
      );
    }

    // Risk Name
    if (!risk.name?.trim()) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» не указано наименование.`, undefined, rNum);
    } else {
      // Warning for cause-style naming
      const lowerName = risk.name.toLowerCase().trim();
      if (
        lowerName.startsWith('отсутствие') ||
        lowerName.startsWith('недостаток') ||
        lowerName.startsWith('высокая нагрузка') ||
        lowerName.startsWith('нехватка')
      ) {
        addWarning(
          1,
          'Регистр Ч.1',
          `Наименование «${risk.name}» сформулировано как причина/фактор («Отсутствие...»), а не как негативное событие.`,
          'Рекомендуется переформулировать в формате «Риск ... вследствие ...» (см. Памятку, раздел 3).',
          rNum
        );
      }
    }

    // Factors & Consequences
    const cleanFactors = (risk.factors || []).map((f) => f.trim()).filter(Boolean);
    if (cleanFactors.length === 0) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» отсутствуют риск-факторы (причины/источники).`, undefined, rNum);
    }

    const cleanConsequences = (risk.consequences || []).map((c) => c.trim()).filter(Boolean);
    if (cleanConsequences.length === 0) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» отсутствует описание возможных последствий.`, undefined, rNum);
    }

    // Scores range check
    if (!risk.probability || risk.probability < 1 || risk.probability > 5) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» балл вероятности вне диапазона 1–5 (${risk.probability}).`, undefined, rNum);
    }
    if (!risk.timeImpact || risk.timeImpact < 1 || risk.timeImpact > 3) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» балл времени влияния вне диапазона 1–3 (${risk.timeImpact}).`, undefined, rNum);
    }
    if (!risk.impact || risk.impact < 1 || risk.impact > 5) {
      addBlocking(1, 'Регистр Ч.1', `У риска «${rNum}» балл влияния вне диапазона 1–5 (${risk.impact}).`, undefined, rNum);
    }

    const inherentScore = calculateRiskScore(risk.probability, risk.timeImpact, risk.impact);

    // 3. Step 2: Part 2 - Measures check
    // If rating >= 0.8 (score >= 8), must have at least one valid measure
    if (inherentScore >= 8) {
      if (!risk.measures || risk.measures.length === 0) {
        addBlocking(
          2,
          'Регистр Ч.2',
          `Для риска «${rNum}» (значимость ${inherentScore} ≥ 8, зона средняя/высокая) не указано ни одного мероприятия по управлению.`,
          'Добавьте хотя бы одно мероприятие с указанием срока, ответственного и формы завершения.',
          rNum
        );
      } else {
        const validMeasures = risk.measures.filter(
          (m) => m.name?.trim() && m.deadline?.trim() && m.responsibleUnit?.trim() && m.completionForm?.trim()
        );
        if (validMeasures.length === 0) {
          addBlocking(
            2,
            'Регистр Ч.2',
            `Для риска «${rNum}» все мероприятия должны содержать наименование, срок, ответственное подразделение и форму завершения.`,
            undefined,
            rNum
          );
        }
      }
    }

    // Warnings on measures
    (risk.measures || []).forEach((m, mIdx) => {
      const mName = m.name?.trim() || '';
      if (mName) {
        const words = mName.split(/\s+/).filter(Boolean);
        if (words.length <= 2 && (mName.toLowerCase().includes('контрол') || mName.toLowerCase().includes('мониторинг'))) {
          addWarning(
            2,
            'Регистр Ч.2',
            `Мероприятие №${mIdx + 1} у риска «${rNum}» сформулировано слишком кратко («${mName}»).`,
            'Укажите конкретное действие и инструмент реализации (раздел 4 Памятки).',
            rNum
          );
        }
      }
      if (m.deadline?.toLowerCase().includes('постоянно')) {
        addWarning(
          2,
          'Регистр Ч.2',
          `У мероприятия №${mIdx + 1} риска «${rNum}» указан срок «постоянно».`,
          'Рекомендуется указать дату начала и периодичность (например, «ежемесячно до 25 числа»).',
          rNum
        );
      }
    });

    // 4. Step 3: Part 3 - Residual risk
    const residualScore = calculateRiskScore(
      risk.residualProbability ?? risk.probability,
      risk.residualTimeImpact ?? risk.timeImpact,
      risk.residualImpact ?? risk.impact
    );

    if (residualScore > inherentScore) {
      addBlocking(
        3,
        'Регистр Ч.3',
        `Для риска «${rNum}» остаточный балл (${residualScore}) превышает присущий балл (${inherentScore}).`,
        'Балл остаточного риска не может быть выше присущего после применения мер управления.',
        rNum
      );
    }

    // 5. Step 4: KPR Panel check
    // If rating is 0.9 or 1.0 (inherentScore >= 15), KPR is MANDATORY
    if (inherentScore >= 15) {
      const kprEntry = (doc.kprList || []).find((k) => k.riskNumber === rNum);
      if (!kprEntry || !kprEntry.leadingKpr?.trim() || !kprEntry.thresholdValue?.trim()) {
        addBlocking(
          4,
          'Панель КПР',
          `Риск «${rNum}» имеет балл ${inherentScore} (рейтинг ≥ 0,9, высокая/крайняя зона), но для него не заполнена Панель КПР.`,
          'Перейдите на вкладку «Панель КПР» и заполните опережающий КПР и пороговое значение.',
          rNum
        );
      }
    }
  });

  // 6. Step 5: Realized risks report validation
  const realizedReport = doc.realizedReport;
  const validClasses: RiskClassId[] = ['1-С', '2-Ф', '3-П', '4-К', '5-О'];

  validClasses.forEach((classId) => {
    const section = realizedReport?.[classId];
    if (!section) {
      addBlocking(5, 'Реализованные риски', `Не заполнен блок отчета о реализованных рисках для класса ${classId}.`);
      return;
    }

    if (!section.hasNoEvents && (!section.events || section.events.length === 0)) {
      addBlocking(
        5,
        'Реализованные риски',
        `Для класса ${classId} не отмечен переключатель «Случаев не было» и не внесено ни одного события.`,
        'Включите «Случаев не было» или добавьте реализованные инциденты.'
      );
    }

    (section.events || []).forEach((ev, evIdx) => {
      if (!ev.description?.trim()) {
        addBlocking(5, 'Реализованные риски', `Для события №${evIdx + 1} класса ${classId} не заполнено описание.`);
      }

      // Check if event references a risk number from register
      let foundMatchingRisk = false;
      for (const rNum of allRiskNumbersInDoc) {
        if (ev.description.includes(rNum)) {
          foundMatchingRisk = true;
          break;
        }
      }
      if (!foundMatchingRisk && allRiskNumbersInDoc.size > 0) {
        addBlocking(
          5,
          'Реализованные риски',
          `В описании события №${evIdx + 1} (${classId}) отсутствует ссылка на номер риска из Регистра (например: 5-О-01).`,
          'Укажите номер риска из Регистра, по которому наступило событие.'
        );
      }

      // Date check
      if (!ev.detectionDate) {
        addBlocking(5, 'Реализованные риски', `Для события №${evIdx + 1} (${classId}) не указана дата фиксации.`);
      }
    });
  });

  // Calculate checklist completion status
  const checklistStatus: Record<string, boolean> = {
    risk_format: !blocking.some((b) => b.message.includes('латинские') || b.message.includes('не соответствует формату')),
    risk_wording: !warnings.some((w) => w.message.includes('причина/фактор')),
    factors_format: doc.risks.length > 0 && doc.risks.every((r) => r.factors.length > 0 && r.consequences.length > 0),
    scores_valid: !blocking.some((b) => b.message.includes('вне диапазона')),
    measures_for_high: !blocking.some((b) => b.section === 'Регистр Ч.2'),
    measures_details: !blocking.some((b) => b.message.includes('должны содержать наименование')),
    residual_le_inherent: !blocking.some((b) => b.section === 'Регистр Ч.3'),
    kpr_filled: !blocking.some((b) => b.section === 'Панель КПР'),
    realized_toggled: !blocking.some((b) => b.section === 'Реализованные риски'),
    header_filled: !blocking.some((b) => b.section === 'Инструкция'),
  };

  return {
    isValid: blocking.length === 0,
    blockingErrors: blocking,
    warnings,
    checklistStatus,
  };
}
