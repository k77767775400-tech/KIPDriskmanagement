/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ScoreDetails {
  score: number;
  ratingCode: string; // "1,0", "0,9", "0,8", "0,6", "0,5"
  ratingText: string; // "1,0 крайне высокая"
  zone: 'Красная' | 'Оранжевая' | 'Жёлтая' | 'Зелёная';
  colorHex: string;
  bgHex: string;
}

/**
 * Calculates risk score: (probability + timeImpact) * impact
 */
export function calculateRiskScore(
  probability: number,
  timeImpact: number,
  impact: number
): number {
  const p = Math.max(1, Math.min(5, Number(probability) || 1));
  const t = Math.max(1, Math.min(3, Number(timeImpact) || 1));
  const i = Math.max(1, Math.min(5, Number(impact) || 1));
  return (p + t) * i;
}

/**
 * Returns rating text according to official template formulas:
 * >= 28 -> "1,0 крайне высокая"
 * >= 15 -> "0,9 высокая"
 * >= 8  -> "0,8 средняя"
 * >= 1  -> "0,6 низкая"
 * otherwise -> "0,5 крайне низкая"
 */
export function getRatingDetails(score: number): ScoreDetails {
  if (score >= 28) {
    return {
      score,
      ratingCode: '1,0',
      ratingText: '1,0 крайне высокая',
      zone: 'Красная',
      colorHex: '#DC2626', // red-600
      bgHex: '#FEE2E2', // red-100
    };
  }
  if (score >= 15) {
    return {
      score,
      ratingCode: '0,9',
      ratingText: '0,9 высокая',
      zone: 'Оранжевая',
      colorHex: '#EA580C', // orange-600
      bgHex: '#FFEDD5', // orange-100
    };
  }
  if (score >= 8) {
    return {
      score,
      ratingCode: '0,8',
      ratingText: '0,8 средняя',
      zone: 'Жёлтая',
      colorHex: '#CA8A04', // yellow-600
      bgHex: '#FEF9C3', // yellow-100
    };
  }
  if (score >= 1) {
    return {
      score,
      ratingCode: '0,6',
      ratingText: '0,6 низкая',
      zone: 'Зелёная',
      colorHex: '#16A34A', // green-600
      bgHex: '#DCFCE7', // green-100
    };
  }
  return {
    score,
    ratingCode: '0,5',
    ratingText: '0,5 крайне низкая',
    zone: 'Зелёная',
    colorHex: '#15803D',
    bgHex: '#F0FDF4',
  };
}

/**
 * Calculates effectiveness text for Part 3:
 * - residual > inherent -> "Ошибка: остаточный выше присущего" (BLOCKING error)
 * - residual < inherent -> "Эффективно: X → Y"
 * - equal -> "Риск не снижен"
 */
export function calculateEffectiveness(
  inherentScore: number,
  residualScore: number
): { text: string; isError: boolean; isEffective: boolean } {
  if (residualScore > inherentScore) {
    return {
      text: 'Ошибка: остаточный выше присущего',
      isError: true,
      isEffective: false,
    };
  }
  if (residualScore < inherentScore) {
    return {
      text: `Эффективно: ${inherentScore} → ${residualScore}`,
      isError: false,
      isEffective: true,
    };
  }
  return {
    text: 'Риск не снижен',
    isError: false,
    isEffective: false,
  };
}

/**
 * Serializes an array of items into numbered list formatted cell:
 * 1) text 1;
 * 2) text 2.
 */
export function formatNumberedList(items: string[]): string {
  const filtered = items.map((i) => i.trim()).filter(Boolean);
  if (filtered.length === 0) return '';
  return filtered
    .map((item, idx) => {
      const clean = item.replace(/^\d+[\)\.]\s*/, '').replace(/[\.;]+$/, '');
      const punctuation = idx === filtered.length - 1 ? '.' : ';';
      return `${idx + 1}) ${clean}${punctuation}`;
    })
    .join('\n');
}

/**
 * Parses a serialized string back to array of items
 */
export function parseNumberedList(serialized: string): string[] {
  if (!serialized) return [];
  const lines = serialized
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);
  return lines.map((line) => line.replace(/^\d+[\)\.]\s*/, '').replace(/[\.;]+$/, '').trim());
}

/**
 * Computes official reporting period string for quarter and year:
 * e.g. quarter 'III', year 2026 -> "01.07.2026–30.09.2026"
 */
export function getQuarterPeriodString(quarter: 'I' | 'II' | 'III' | 'IV', year: number): string {
  switch (quarter) {
    case 'I':
      return `01.01.${year}–31.03.${year}`;
    case 'II':
      return `01.04.${year}–30.06.${year}`;
    case 'III':
      return `01.07.${year}–30.09.${year}`;
    case 'IV':
      return `01.10.${year}–31.12.${year}`;
  }
}

/**
 * Calculates submission deadline:
 * Default for IV and III quarter is 31 ноября (31.11.{year})
 */
export function getQuarterSubmissionDeadline(quarter: 'I' | 'II' | 'III' | 'IV', year: number): {
  deadlineDate: Date;
  deadlineString: string;
  isOverdue: (currentDate?: Date) => boolean;
} {
  // Official deadline for IV quarter (and III quarter): 30 ноября (30.11.{year})
  if (quarter === 'IV' || quarter === 'III') {
    // JavaScript Date month 10 is November. End of November (30th) is used for the calendar threshold.
    const deadlineDate = new Date(year, 10, 30, 23, 59, 59);
    return {
      deadlineDate,
      deadlineString: `30.11.${year} (30 ноября)`,
      isOverdue: (now: Date = new Date()) => now > deadlineDate,
    };
  }

  let month = 0; // 0-indexed
  let deadlineYear = year;
  switch (quarter) {
    case 'I':
      month = 3; // April 5th
      break;
    case 'II':
      month = 6; // July 5th
      break;
  }
  const deadlineDate = new Date(deadlineYear, month, 5, 23, 59, 59);
  const pad = (n: number) => n.toString().padStart(2, '0');
  const deadlineString = `05.${pad(month + 1)}.${deadlineYear}`;

  return {
    deadlineDate,
    deadlineString,
    isOverdue: (now: Date = new Date()) => now > deadlineDate,
  };
}
