/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { runAllAcceptanceTests, TestResult } from '../utils/unitTests';
import { CheckCircle2, XCircle, Play, RefreshCw, ShieldCheck, Cpu } from 'lucide-react';

export const UnitTestsRunner: React.FC = () => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runTests = async () => {
    setIsRunning(true);
    try {
      const res = await runAllAcceptanceTests();
      setResults(res);
    } catch (e: any) {
      console.error('Test run failed:', e);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runTests();
  }, []);

  const total = results.length;
  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = total - passedCount;

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-wider font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
            Модуль приемочного тестирования (Acceptance Tests)
          </span>
          <h2 className="text-lg font-bold mt-2 text-slate-900">
            Верификация формул, шкал, валидации и экспорта Excel
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Автоматическое тестирование всех граничных условий (7/8, 14/15, 27/28), блокировок Памяток и синхронизации строк листов Ч.1 / Ч.2 / Ч.3.
          </p>
        </div>

        <button
          type="button"
          onClick={runTests}
          disabled={isRunning}
          className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition-colors shrink-0"
        >
          {isRunning ? (
            <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
          ) : (
            <Play className="w-4 h-4 text-emerald-400" />
          )}
          <span>{isRunning ? 'Выполнение тестов...' : 'Перезапустить все тесты'}</span>
        </button>
      </div>

      {/* Summary Scorecard */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 block font-medium">Всего проверок:</span>
          <span className="text-2xl font-bold text-slate-900 mt-1 block font-mono">{total}</span>
        </div>

        <div className="bg-emerald-50/80 p-5 rounded-xl border border-emerald-200 shadow-xs">
          <span className="text-xs text-emerald-800 block font-bold">Пройдено успешно:</span>
          <span className="text-2xl font-bold text-emerald-700 mt-1 block font-mono">
            {passedCount} / {total}
          </span>
        </div>

        <div
          className={`p-5 rounded-xl border shadow-xs ${
            failedCount > 0
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-slate-50 border-slate-200 text-slate-600'
          }`}
        >
          <span className="text-xs block font-bold">Ошибок:</span>
          <span
            className={`text-2xl font-bold mt-1 block font-mono ${
              failedCount > 0 ? 'text-rose-700' : 'text-slate-400'
            }`}
          >
            {failedCount}
          </span>
        </div>
      </div>

      {/* Tests Results List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 font-bold text-xs text-slate-700 uppercase tracking-wider">
          Результаты прогона тест-кейсов
        </div>

        <div className="divide-y divide-slate-100">
          {results.map((test) => (
            <div
              key={test.id}
              className={`p-4 flex items-start justify-between gap-4 transition-colors ${
                test.passed ? 'hover:bg-slate-50' : 'bg-rose-50/40 hover:bg-rose-50/70'
              }`}
            >
              <div className="flex items-start space-x-3">
                <span className="mt-0.5 shrink-0">
                  {test.passed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-600" />
                  )}
                </span>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                      {test.category}
                    </span>
                    <span className="text-xs font-bold text-slate-900">{test.name}</span>
                  </div>
                  <p
                    className={`mt-1 text-xs font-mono ${
                      test.passed ? 'text-slate-600' : 'text-rose-700 font-bold'
                    }`}
                  >
                    {test.message}
                  </p>
                </div>
              </div>

              <span
                className={`text-xs font-bold font-mono px-2.5 py-1 rounded-md shrink-0 border ${
                  test.passed
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : 'bg-rose-100 text-rose-800 border-rose-200'
                }`}
              >
                {test.passed ? 'PASSED' : 'FAILED'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
