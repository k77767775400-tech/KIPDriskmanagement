import { pgTable, serial, text, integer, timestamp, jsonb } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  name: text('name').notNull(),
  login: text('login').notNull().unique(),
  password: text('password').notNull(), // Hashed with scrypt
  position: text('position').notNull(),
  department: text('department').notNull(),
  role: text('role').notNull(), // 'department' | 'risk_manager' | 'admin'
  email: text('email'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const registers = pgTable('registers', {
  id: text('id').primaryKey(), // e.g. "REG-DEP1-2026-Q4"
  department: text('department').notNull(),
  quarter: text('quarter').notNull(),
  year: integer('year').notNull(),
  status: text('status').notNull(), // 'draft' | 'submitted' | 'accepted' | 'returned'
  documentData: jsonb('document_data').notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const documentLocks = pgTable('document_locks', {
  documentId: text('document_id').primaryKey(),
  lockedByUserId: text('locked_by_user_id').notNull(),
  lockedByUserName: text('locked_by_user_name').notNull(),
  lockedByUserDepartment: text('locked_by_user_department').notNull(),
  lockedAt: timestamp('locked_at').defaultNow().notNull(),
  heartbeatAt: timestamp('heartbeat_at').defaultNow().notNull(),
});

export const schema = {
  users,
  registers,
  documentLocks,
};
