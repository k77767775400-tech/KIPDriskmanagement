/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type RiskClassId = '1-С' | '2-Ф' | '3-П' | '4-К' | '5-О';

export interface RiskClassInfo {
  id: RiskClassId;
  codeLetter: string; // Cyrillic: С, Ф, П, К, О
  numberPrefix: number; // 1, 2, 3, 4, 5
  title: string;
  shortTitle: string;
  description: string;
}

export const RISK_CLASSES: Record<RiskClassId, RiskClassInfo> = {
  '1-С': {
    id: '1-С',
    codeLetter: 'С',
    numberPrefix: 1,
    title: '1-С. Стратегические риски',
    shortTitle: 'Стратегические',
    description: 'Риски недостижения стратегических целей, срыва государственного задания и изменения внешних условий',
  },
  '2-Ф': {
    id: '2-Ф',
    codeLetter: 'Ф',
    numberPrefix: 2,
    title: '2-Ф. Финансовые риски',
    shortTitle: 'Финансовые',
    description: 'Риски дефицита финансирования, нецелевого использования бюджетных средств и непредвиденных расходов',
  },
  '3-П': {
    id: '3-П',
    codeLetter: 'П',
    numberPrefix: 3,
    title: '3-П. Правовые риски',
    shortTitle: 'Правовые',
    description: 'Риски судебных споров, нарушения договорных обязательств и регуляторных требований',
  },
  '4-К': {
    id: '4-К',
    codeLetter: 'К',
    numberPrefix: 4,
    title: '4-К. Комплаенс-риски',
    shortTitle: 'Комплаенс',
    description: 'Риски антикоррупционных нарушений, конфликта интересов, несоблюдения этических и профессиональных стандартов',
  },
  '5-О': {
    id: '5-О',
    codeLetter: 'О',
    numberPrefix: 5,
    title: '5-О. Операционные риски',
    shortTitle: 'Операционные',
    description: 'Риски сбоев ИТ-инфраструктуры, утечки данных, недостатка кадров и неэффективности внутренних процессов',
  },
};

export type MeasureGoal = 'А' | 'Б' | 'В' | 'Г';

export const MEASURE_GOALS: Record<MeasureGoal, { code: MeasureGoal; label: string }> = {
  А: { code: 'А', label: 'А) снижение ущерба' },
  Б: { code: 'Б', label: 'Б) снижение вероятности' },
  В: { code: 'В', label: 'В) предотвращение риска' },
  Г: { code: 'Г', label: 'Г) восстановление потерь' },
};

export type MeasureStatus = 'Исполнено' | 'В процессе исполнения' | 'Не исполнено';

export interface RiskMeasure {
  id: string;
  name: string; // Наименование мероприятия
  goal: MeasureGoal; // Цель (А/Б/В/Г)
  estimatedCost: number; // Оценочная стоимость, тыс. тенге (0 if none)
  costBenefitAnalysis: string; // Сопоставление затрат с результатами
  deadline: string; // Срок реализации
  completionForm: string; // Форма завершения
  responsibleUnit: string; // Ответственное подразделение
  status: MeasureStatus; // Факт выполнения
}

export interface RiskItem {
  id: string;
  riskNumber: string; // e.g. "5-О-01"
  classId: RiskClassId;
  name: string; // Наименование риска
  factors: string[]; // Repeatable items -> serialized as "1) ...;\n2) ..."
  consequences: string[]; // Repeatable items -> serialized as "1) ...;\n2) ..."
  ownerUnit: string; // Auto from department

  // Scoring inherent (Присущий риск)
  probability: 1 | 2 | 3 | 4 | 5; // 1 to 5
  timeImpact: 1 | 2 | 3; // 1 to 3
  impact: 1 | 2 | 3 | 4 | 5; // 1 to 5
  impactType?: 'financial' | 'non_financial'; // Helper for scale view
  damageThousandKzt?: number; // Размер ущерба (тыс. тенге, опционально)

  // Part 2: Measures
  measures: RiskMeasure[];

  // Part 3: Residual risk (Остаточный риск)
  residualProbability: 1 | 2 | 3 | 4 | 5;
  residualTimeImpact: 1 | 2 | 3;
  residualImpact: 1 | 2 | 3 | 4 | 5;
  residualDamageThousandKzt?: number;
}

export interface KprItem {
  id: string;
  riskNumber: string; // Must refer to a risk with rating 0.9 or 1.0
  leadingKpr: string; // КПР опережающий
  laggingKpr: string; // КПР итоговый
  thresholdValue: string; // Пороговое значение КПР
  managementMeasure: string; // Мероприятие по управлению риском
}

export interface RealizedEvent {
  id: string;
  classId: RiskClassId;
  eventNumber: number;
  detectionDate: string; // YYYY-MM-DD or DD.MM.YYYY
  description: string; // Детальное описание (содержит номер риска из регистра)
  occurrenceLocation: string; // Место наступления
  causes: string; // Причины
  initialDamage: string; // Ущерб первоначальный
  finalDamage: string; // Ущерб окончательный (число или "уточняется")
  takenMeasures: string; // Принятые меры
  effectivenessEvaluation: string; // Оценка эффективности
  department: string; // Структурное подразделение
  isCarriedOver?: boolean; // Перенесено с предыдущего квартала
}

export interface RealizedClassSection {
  classId: RiskClassId;
  hasNoEvents: boolean; // Toggle "Случаев не было"
  events: RealizedEvent[];
}

export type SubmissionStatus =
  | 'draft' // Черновик
  | 'submitted' // На рассмотрении менеджера по рискам
  | 'returned' // Возвращен на доработку с замечаниями
  | 'resubmitted' // Повторно отправлен
  | 'accepted'; // Согласован / Принят

export interface HeaderData {
  department: string; // «Отдел данных, цифровых решений и AI»
  quarter: 'I' | 'II' | 'III' | 'IV';
  year: number; // e.g. 2026
  periodString: string; // «01.07.2026–30.09.2026»
  coordinatorName: string; // «Алиев Марат»
  coordinatorPosition: string; // «Руководитель отдела»
  curatingDeputyName?: string; // Курирующий заместитель председателя
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  author: string;
  role: string;
  action: string;
  comment?: string;
  diffSummary?: string;
}

export interface RiskRegisterDocument {
  id: string;
  header: HeaderData;
  risks: RiskItem[];
  kprList: KprItem[];
  realizedReport: Record<RiskClassId, RealizedClassSection>;
  status: SubmissionStatus;
  version: number;
  submittedAt?: string;
  acceptedAt?: string;
  returnComment?: string;
  history: AuditRecord[];
  createdAt: string;
  updatedAt: string;
}

export interface NomenclatureItem {
  id: string;
  classId: RiskClassId;
  riskNumber: string; // e.g. "5-О-01"
  name: string;
  defaultFactors?: string[];
  defaultConsequences?: string[];
  isPendingApproval?: boolean;
}

export type UserRole = 'department' | 'risk_manager' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  position: string;
  department: string;
  role: UserRole;
  email: string;
  login: string;
  password?: string;
}

export interface ValidationItem {
  id: string;
  type: 'blocking' | 'warning';
  step: number;
  section: string;
  riskNumber?: string;
  message: string;
  recommendation?: string;
}
